import torch
from torch import nn
from ngf.utils.utils import MultiLayerPerceptron

class AuxiliaryNet(nn.Module):
    """
    torch module for geometry generator parameterized by a neural network
    """
    def __init__(self, dim, feature_shape=0, feature_keys=None,
             hidden_units=(), activation=nn.Tanh(), normalize=False, 
             name='auxiliary_net', device=torch.device('cpu')):
        '''
        :param dim: dimension 
        :feature_shape: the dimension of features
        :feature_keys: the keys of features
        :param hidden units: the number of hidden layers for the potential gradient
        :param activation: activation function for the neural network
        :param normalize: whether to normalize input
        '''
        super(AuxiliaryNet, self).__init__()

        self.dim, self.units, self.activation = dim, hidden_units, activation
        self.aux_net = MultiLayerPerceptron(
                    input_dim=dim+feature_shape, output_dim=dim, 
                    hidden_units=hidden_units, activation=activation, 
                    device=device, name=name+'_mlp')

        if feature_keys is None:
            self.feature_keys = []
        else:
            self.feature_keys = feature_keys
        
    def __call__(self, x, **features):
        '''
        :param x: generalized coordinate in batch
        :return: auxiliary factor for geometry or potential
        '''
        selected_features = {key: features[key] for key in self.feature_keys}
        x_aug = torch.cat((x, )+tuple(selected_features.values()), axis=1)
        aux_factor = self.aux_net(x_aug)
        
        return aux_factor

    def freeze(self):
        self.aux_net.freeze()
