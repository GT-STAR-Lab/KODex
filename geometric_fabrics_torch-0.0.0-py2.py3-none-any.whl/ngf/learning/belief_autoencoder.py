import torch
import torch.nn as nn
from torch.nn import functional as F
from ngf.learning.transformers import Block

class BeliefAutoEncoder(nn.Module):
    def __init__(self, belief_dim, action_dim, embedding_dim, num_points=400,
        dropout_rate=0, feature_shape=0, feature_keys=None, num_heads=4, num_layers=4, 
        device=torch.device('cpu'), dtype=torch.float32):
        super().__init__()    

        self.encoder = BeliefEncoder(belief_dim, action_dim, embedding_dim, 
            dropout_rate, feature_shape, feature_keys, num_heads, num_layers, device, dtype)
        self.decoder = BeliefDecoder(belief_dim, action_dim, num_points, device)

    def forward(self, q, **batch):

        x = self.encoder(q, **batch)

        encoded_embedding = x 
        
        # x = self.decoder.decode2pcd(x)

        return encoded_embedding, x

    def freeze(self):
        self.encoder.freeze()
        self.decoder.freeze()

class BeliefEncoder(nn.Module):
    def __init__(self, belief_dim, action_dim, embedding_dim, 
        dropout_rate, feature_shape=0, feature_keys=None, 
        num_heads=4, num_layers=4, 
        device=torch.device('cpu'), dtype=torch.float32):
        super().__init__()

        # embedding layer
        self.embedding = nn.Linear(action_dim+feature_shape, embedding_dim, device=device)
        # dropout
        self.dropout = nn.Dropout(dropout_rate)
        # attention layer
        self.attention_layers = nn.Sequential(*[Block(embedding_dim, num_heads, dropout_rate, device=device) for _ in range(num_layers)])
        # projection layer
        self.projecting = nn.Linear(embedding_dim, belief_dim, device=device)

        self.embedding_dim = embedding_dim
        self.dtype = dtype
        self.device = device

        if feature_keys is None:
            self.feature_keys = []
        else:
            self.feature_keys = feature_keys

        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, (nn.Linear, nn.Embedding)):
            module.weight.data.normal_(mean=0.0, std=0.02)
            if isinstance(module, nn.Linear) and module.bias is not None:
                module.bias.data.zero_()
        elif isinstance(module, nn.LayerNorm):
            module.bias.data.zero_()
            module.weight.data.fill_(1.0)

    def positional_embedding(self, seq_len):
        theta = torch.arange(seq_len).reshape(-1, 1)/torch.pow(10000, 2*torch.arange(self.embedding_dim/2).reshape(1, -1)/self.embedding_dim)
        pes = torch.zeros(seq_len, self.embedding_dim, dtype=self.dtype, device=self.device)
        pes[:, ::2] = torch.sin(theta)
        pes[:, 1::2] = torch.cos(theta)

        return pes.reshape([1, seq_len, self.embedding_dim])

    def forward_mapping(self, q):
        x = self.embedding(q) ## [ B x T x embedding_dim ]
        # add positional embedding
        x += self.positional_embedding(x.shape[1])
        x = self.dropout(x)
        return x

    def attention(self, x, masks=None):
        for att_layer in self.attention_layers:
            x = att_layer(x, masks)
        return x

    def forward(self, q, **batch):
        # embedding input sequence 
        selected_features = {key: batch[key] for key in self.feature_keys}
        q = torch.cat((q, )+tuple(selected_features.values()), axis=-1)
        x = self.forward_mapping(q)

        if "masks" in batch.keys():
            masks = batch['masks']
        else:
            masks = None
        z = self.attention(x, masks=masks) ## [ B x T x embedding_dim ]
        # projection
        output = self.projecting(z)
        
        return output

    def freeze(self):
        def _freeze_module(m):
            for p in m.parameters():
                p.requires_grad = False

        _freeze_module(self.embedding)
        _freeze_module(self.attention_layers)
        _freeze_module(self.projecting)

class BeliefDecoder(nn.Module):
    def __init__(self, belief_dim, action_dim, num_points = 400, device=torch.device('cpu')):
        super(BeliefDecoder, self).__init__()
        
        # decode for point cloud
        self.num_points = num_points
        self.fc1 = nn.Linear(belief_dim, 128, device=device)
        self.fc2 = nn.Linear(128, 256, device=device)
        self.fc3 = nn.Linear(256, 512, device=device)
        self.fc4 = nn.Linear(512, num_points * 3, device=device)
        self.th = nn.Tanh()

        # decode for state
        self.root_dim = belief_dim
        self.action_dim = action_dim
        self.fcs1 = nn.Linear(self.root_dim , action_dim, device=device)

    def decode2pcd(self, x):
        batchsize = x.size()[0]
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        x = self.th(self.fc4(x))
        x = x.view(batchsize, -1, 3)

        return x

    def decode2state(self, x):
        if self.root_dim != self.action_dim:
            x = self.fcs1(x)

        return x
        
    def freeze(self):
        def _freeze_module(m):
            for p in m.parameters():
                p.requires_grad = False

        _freeze_module(self.fc1)
        _freeze_module(self.fc2)
        _freeze_module(self.fc3)
        _freeze_module(self.fc4)
        _freeze_module(self.fcs1)
