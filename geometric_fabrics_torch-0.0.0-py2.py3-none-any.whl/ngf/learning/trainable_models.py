import torch
from torch import nn
from abc import ABC, abstractmethod
from tqdm import tqdm
import time
import os
from torch.utils.data import ConcatDataset, DataLoader

class TrainableModel(nn.Module, ABC):
    '''
    generic torch trainable module
    '''
    def __init__(self, **kwargs):
        super(TrainableModel, self).__init__()

    @abstractmethod
    def loss(self, **kwargs):
        """
        :param: inputs in batch
        :return: loss
        """

    def train_model(
        self, optimizer, warmup,
        dataset, key_list, 
        validation_dataset=None,
        n_epochs=500,
        batch_size=None, 
        shuffle=True,
        clip_grad=False, clip_value_grad=0.1,
        clip_weight=False, clip_value_weight=2,
        clip_loss_value=1e3,
        stop_threshold=float('inf'),
        checkpoint_path='./ckpt', checkpoint_freq=20,
        save_best=True,
        print_freq=5, 
        verbose=False):
        '''
        train the model
        :param optimzier: optimizer
        :param dataset: training dataset
        :param key_list: training dataset key list
        :param n_epochs: maximum number of epochs to train
        :param batch_size: minibatch size
        :param clip_weight: whether to clip network weights
        :param clip_weight_value: if clip weights, the maximum
                                  absolute value for network
        :param clip_loss_value: the maximum loss value to update
                                 network, skip update if larger
        :param stop_threshold: terminate training the not improving
                                for the last giving number of epochs
        :param checkpoint_path: path to save model checkpoints
        :param checkpoint_freq: frequency to save model checkpoints
        :param save_best: whether to save the current best model
        :param print_freq: frequency for printing in commend line
        :param verbose: whether to print when saving checkpoints
        :return: training loss for the final iteration
        '''

        if validation_dataset is not None:
            validation_loader = DataLoader(
                dataset=validation_dataset,
                batch_size=len(validation_dataset),
                shuffle=False
            )
            if checkpoint_path is not None and save_best:
                best_validation_model_path = os.path.join(checkpoint_path, '..', '..', 'best_validation_model')
                if not os.path.exists(best_validation_model_path):
                    print('create directory: {}'.format(best_validation_model_path))
                    os.makedirs(best_validation_model_path)
                else:
                    for f in os.listdir(best_validation_model_path):
                        os.remove(os.path.join(best_validation_model_path, f))

        if checkpoint_path is not None and save_best:
            best_train_model_path = os.path.join(checkpoint_path, '..', '..', 'best_train_model')
            if not os.path.exists(best_train_model_path):
                print('create directory: {}'.format(best_train_model_path))
                os.makedirs(best_train_model_path)
            else:
                for f in os.listdir(best_train_model_path):
                    os.remove(os.path.join(best_train_model_path, f))

        # if batch_size is None, train in batch
        n_samples = len(dataset)
        if batch_size is None:
            train_loader = DataLoader(
                dataset=dataset,
                batch_size=n_samples,
                shuffle=shuffle
            )
            batch_size = n_samples
        else:
            train_loader = DataLoader(
                dataset=dataset,
                batch_size=batch_size,
                shuffle=shuffle
            )

        ts = time.time()

        # best epoch training loss
        best_train_loss = float('inf')
        best_train_epoch = 0
        best_model_filename = None
        best_validation_loss = float('inf')
        best_validation_epoch = 0
        best_validation_model_filename = None
        # train the model
        for epoch in tqdm(range(n_epochs)):
            # save intermediate models in training process, save the initial model as the first one
            if epoch != 0 and epoch % checkpoint_freq == 0:
                model_filename = 'ckpt_{}.pt'.format(epoch)
                torch.save(self.state_dict(), os.path.join(checkpoint_path, model_filename))
                if verbose:
                    print("\t[Checkpoint] Saved checkpoint for epoch {} to {}".format(epoch, checkpoint_path))

            # iterate over minibatches
            train_loss = 0.
            validation_loss = 0.
            for data_list in train_loader:
                batch = {key:data for key, data in zip(key_list, data_list)}

                # compute loss
                loss = self.loss(**batch)
                train_loss += loss.item()

                if loss > clip_loss_value:
                    print('loss too large, skip')
                    continue

                # backward pass
                optimizer.zero_grad()
                loss.backward()

                # clip gradient based on norm
                if clip_grad:
                    torch.nn.utils.clip_grad_norm_(
                        self.parameters(),
                        clip_value_grad
                    )
                # update parameters
                optimizer.step()

            if warmup is not None:
                warmup.step()

            # train_loss = train_loss/float(n_samples)
            if train_loss < best_train_loss:
                best_train_epoch = epoch
                best_train_loss = train_loss
                if checkpoint_path is not None and save_best:
                    if best_model_filename is not None:
                        os.remove(os.path.join(best_train_model_path, best_model_filename))
                    best_model_filename = 'ckpt_{}.pt'.format(epoch)
                    torch.save(self.state_dict(), os.path.join(best_train_model_path, best_model_filename))
                    if verbose:
                        print("\t[Best model] Epoch {}: the best performing model so far with loss {}".format(epoch, train_loss))
                        print("\t[Best model] Saved current best model to {}".format(best_train_model_path))

            # report loss in command line
            if epoch % print_freq == (print_freq - 1):
                # print(optimizer.param_groups[0]['lr'])
                print('\tEpoch [{}/{}]: current train loss is {}, best loss is {} and epoch is {}, time elapsed {} second'.format(
                    epoch + 1, n_epochs,
                    train_loss,
                    best_train_loss,
                    best_train_epoch,
                    time.time()-ts)
                )

            if validation_dataset is not None:
                for validation_data_list in validation_loader:
                    validation_batch = {key:data for key, data in zip(key_list, validation_data_list)}
                    validation_loss = self.loss(**validation_batch)

                if validation_loss < best_validation_loss:
                    best_validation_epoch = epoch
                    best_validation_loss = validation_loss
                    if checkpoint_path is not None and save_best:
                        if best_validation_model_filename is not None:
                            os.remove(os.path.join(best_validation_model_path, best_validation_model_filename))
                        best_validation_model_filename = 'ckpt_{}.pt'.format(epoch)
                        torch.save(self.state_dict(), os.path.join(best_validation_model_path, best_validation_model_filename))
                    
            # report loss in command line
            if epoch % print_freq == (print_freq - 1):
                # print(optimizer.param_groups[0]['lr'])
                print('\tcurrent validation loss is {}, best loss is {} and epoch is {}'.format(
                    validation_loss,
                    best_validation_loss,
                    best_validation_epoch)
                )

        if validation_dataset is not None: 
            best_validation_loss_dir = os.path.join(checkpoint_path, '..', '..', 'best_validation_loss.txt')
            validation_loss_dict = dict(
                epoch = best_validation_epoch,
                loss = float(best_validation_loss),
                time = (time.time()-ts)*3.75
            )
            with open(best_validation_loss_dir, 'w') as f:
                print(validation_loss_dict, file=f) 

        return train_loss

