from ngf.controllers.controllers import GeometricPolicyController
from ngf.learning.lagrangian_nets import LagrangianCholNet
from ngf.learning.geometry_nets import GeometryNet
from ngf.learning.potential_nets import PotentialNet
from ngf.learning.auxiliary_nets import AuxiliaryNet
from ngf.controllers.potentials import QuadraticPotential
import torch
from torch import nn

class GMPNet(GeometricPolicyController):
    """
    torch module for neural network geometric motion policy
    """
    def __init__(self, dim, feature_shape=0, feature_keys=None, 
            hidden_units=(), activation=nn.Tanh(), add_potential=False, use_high_level_policy=False,
            normalize=False, dtype=torch.float32, name="geometry_net", device=torch.device('cpu'),
            timed=False, debug=False):
        '''
        :param dim: the dimension of input of the potential function gradient
                    (and hence the dimension of the potential gradient)
        :feature_shape: the dimension of features
        :feature_keys: the keys of features
        :param hidden units: the number of hidden layers for the potential gradient
        :param activation: activation function for the neural network
        :param add_potential: whether to add potential 
        :param normalize: whether to normalize input
        :param debug: whether to output debug info
        :param dtype: data type of the graph
        :param name: name for the module
        '''
        L_e = LagrangianCholNet(dim, feature_shape=feature_shape, feature_keys=feature_keys, 
                    hidden_units=hidden_units, activation=activation, dtype=dtype,
                    name=name+'_lagrangian_net', device=device)
        aux_net = AuxiliaryNet(dim, feature_shape=feature_shape, feature_keys=feature_keys,
                    hidden_units=hidden_units, activation=activation, normalize=normalize,
                    name=name+'_auxiliary_net', device=device)
        phi2 = GeometryNet(aux_net)

        if add_potential:
            if use_high_level_policy:
                psi = QuadraticPotential(n_dims=dim)
            else:
                aux_psi = AuxiliaryNet(dim, feature_shape=feature_shape, feature_keys=feature_keys,
                            hidden_units=hidden_units, activation=activation, normalize=normalize,
                            name='potential_auxiliary_net', device=device)
                psi = PotentialNet(aux_net=aux_psi)
        else:
            psi = None

        super().__init__(Phi2=phi2, Psi=psi, L_e=L_e, name=name, debug=debug, timed=False)