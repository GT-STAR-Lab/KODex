import torch
from torch import nn
from ngf.utils.utils import MultiLayerPerceptron, ipm

class LagrangianCholNet(nn.Module):
    """
    tensorflow module for neural network Lagrangian
    """
    def __init__(self, dim, feature_shape=0, feature_keys=None,
            hidden_units=(), activation=nn.Tanh(), normalize=False, 
            dtype=torch.float32, name='lagrangian_net', device=torch.device('cpu')):
        '''
        :param dim: the dimension of input of the potential function gradient
                    (and hence the dimension of the potential gradient)
        :feature_shape: the dimension of features
        :feature_keys: the keys of features
        :param hidden units: the number of hidden layers for the potential gradient
        :param activation: activation function for the neural network
        :param dtype: data type of the graph
        :param normalize: whether to normalize input
        '''
        super(LagrangianCholNet, self).__init__()

        self.dim, self.units, self.activation = dim, hidden_units, activation
        self.dtype = dtype
        self.metric_net = MultiLayerPerceptron(
            input_dim=dim+feature_shape, output_dim=dim * (dim + 1) // 2,
            hidden_units=hidden_units, activation=activation, device=device, name=name+'_mlp')

        if feature_keys is None:
            self.feature_keys = []
        else:
            self.feature_keys = feature_keys

    def get_metric(self, x, offset=1e-5, **features):
        '''
        obtain metric value
        :param x: generalized coordinate in batch
        :param offset: offset to provide positive diagonal elements
        :return: Metric M
        '''
        # cholesky decomposition of the metric
        selected_features = {key: features[key] for key in self.feature_keys}
        x_aug = torch.cat((x, )+tuple(selected_features.values()), axis=1)
        
        n_samples = x.size()[0]
        lower_matrix = torch.zeros(n_samples, self.dim, self.dim, device=x.device, dtype=self.dtype)
        lower_flat = self.metric_net(x_aug)
        off_diag_ind = torch.tril_indices(row=self.dim, col=self.dim)
        lower_matrix[:, off_diag_ind[0], off_diag_ind[1]] = lower_flat
        diag = torch.diagonal(lower_matrix, dim1=-2, dim2=-1)
        diag = torch.abs(diag + 1) + offset
        diag_ind = torch.arange(self.dim)
        lower_matrix[:, diag_ind, diag_ind] = diag

        # metric
        metric = torch.matmul(lower_matrix, lower_matrix.transpose(1, 2))

        return  metric

    def __call__(self, x, xd, offset=1e-5, **features):
        '''
        compute the L = 0.5 * xd^T M xd; where the cholesky decomposition
        of M is parameterized by a neural network
        :param x: generalized coordinate in batch
        :param xd: generalized velocity in batch
        :param offset: offset to provide positive diagonal elements
        :return: Lagrangian L = 0.5 * xd^T M xd
        '''
        metric = self.get_metric(x, offset=offset, **features)
        # lagrangian
        L = 0.5 * ipm(xd, xd, metric).reshape(-1, 1)
        return L

    def freeze(self):
        self.metric_net.freeze()