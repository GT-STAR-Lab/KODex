import torch
from torch import nn
from ngf.utils.utils import MultiLayerPerceptron

class TaskMapNet(nn.Module):
    """
    torch module for taskmap parameterized by a neural network
    """
    def __init__(self, input_dim, output_dim, feature_shape=0, feature_keys=None,
             hidden_units=(), activation=nn.Tanh(), normalize=False, 
             name='taskmap_net', device=torch.device('cpu')):
        '''
        :param input_dim: the dimension of input 
        :param output_dim: the dimension of output 
        :feature_shape: the dimension of features
        :feature_keys: the keys of features
        :param hidden units: the number of hidden layers for the potential gradient
        :param activation: activation function for the neural network
        :param normalize: whether to normalize input
        '''
        super(TaskMapNet, self).__init__()

        self.input_dim, self.output_dim, self.units, self.activation = input_dim, output_dim, hidden_units, activation
        self.taskmap_net = MultiLayerPerceptron(
                input_dim=input_dim+feature_shape, output_dim=output_dim, 
                hidden_units=hidden_units,activation=activation, 
                init_weight=0.2, device=device, name=name+'_mlp')

        if feature_keys is None:
            self.feature_keys = []
        else:
            self.feature_keys = feature_keys
        
    def __call__(self, q, **features):
        '''
        :param q: generalized coordinate in batch
        :return: taskmap coordinate
        '''
        selected_features = {key: features[key] for key in self.feature_keys}
        state = torch.cat((q, ) + tuple(selected_features.values()), axis=1)
        x = self.taskmap_net(state)
        
        return x