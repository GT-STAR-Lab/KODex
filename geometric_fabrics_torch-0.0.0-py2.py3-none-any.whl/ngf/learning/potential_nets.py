import torch
from torch import nn
from ngf.utils.utils import ip, batch_gradient_safe

class PotentialNet(nn.Module):
    """
    torch module for potential generator parameterized by a neural network
    """
    def __init__(self, aux_net):
        '''
        :param aux_net: auxiliary network
        '''
        super(PotentialNet, self).__init__()
        self.aux_net = aux_net

    def __call__(self, x, **features):
        '''
        :param x: generalized coordinate in batch
        :return: potential gradient
        '''
        # # finite diff
        # eps = 1e-3
        # x_repeated = x.unsqueeze(1).repeat(1, x.shape[-1], 1)
        # dx = torch.eye(x.shape[-1], dtype=x.dtype, device=x.device)*eps
        # aux_factor_plus = self.aux_net(x_repeated+dx, **features)
        # potential_plus = torch.einsum('bij,bij->bi', aux_factor_plus, aux_factor_plus)
        # aux_factor_minus = self.aux_net(x_repeated-dx, **features)
        # potential_minus = torch.einsum('bij,bij->bi', aux_factor_minus, aux_factor_minus)

        # psi = 0.5*(potential_plus - potential_minus)/eps
        
        aux_factor = self.aux_net(x, **features)
        # get potential
        potential = ip(aux_factor, aux_factor)
        psi = batch_gradient_safe(potential, x, create_graph=self.training, retain_graph=self.training)

        return psi
