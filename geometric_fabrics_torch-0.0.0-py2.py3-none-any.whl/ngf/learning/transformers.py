import torch
import torch.nn as nn
from torch.nn import functional as F
import numpy as np
import math

class CausalSelfAttention(nn.Module):
    def __init__(self, embedding_dim, num_heads, dropout_rate, device=torch.device('cpu')):
        super().__init__()

        assert embedding_dim % num_heads == 0
        # key, query, value projections for all heads
        self.key = nn.Linear(embedding_dim, embedding_dim, device=device)
        self.query = nn.Linear(embedding_dim, embedding_dim, device=device)
        self.value = nn.Linear(embedding_dim, embedding_dim, device=device)
        self.project = nn.Linear(embedding_dim, embedding_dim, device=device)
        # regularization
        self.dropout = nn.Dropout(dropout_rate)
        self.num_heads = num_heads        

    def forward(self, x, masks=None, layer_past=None):
        B, T, C = x.shape
        head_dim = C // self.num_heads

        # calculate key, query, values for all heads in batch and move head forward to be the batch dim
        ## [ B x num_heads x T x head_dim ]
        k = self.key(x).view(B, T, self.num_heads, head_dim).transpose(1, 2) # (B, nh, T, hs)
        q = self.query(x).view(B, T, self.num_heads, head_dim).transpose(1, 2) # (B, nh, T, hs)
        v = self.value(x).view(B, T, self.num_heads, head_dim).transpose(1, 2) # (B, nh, T, hs)

        # causal self-attention; Self-attend: (B, num_heads, T, head_dim) x (B, num_heads, head_dim, T) -> (B, num_heads, T, T)
        ## [ B x num_heads x T x T ]
        attention = (q @ k.transpose(-2, -1)) * (1.0 / math.sqrt(k.size(-1)))
        # mask 
        if masks is None:
            masks = torch.tril(torch.ones(T, T, device=x.device)).view(1, 1, T, T)
        else:
            masks = masks.view(B, 1, T, T)
        attention = attention.masked_fill(masks == 0, float('-inf'))
        attention = F.softmax(attention, dim=-1)
        attention = self.dropout(attention)
        ## [ B x num_heads x T x head_dim ]
        y = attention @ v # (B, nh, T, T) x (B, nh, T, hs) -> (B, nh, T, hs)
        ## [ B x T x embedding_dim ]
        y = y.transpose(1, 2).contiguous().view(B, T, C) # re-assemble all head outputs side by side
        # output projection
        y = self.project(y)
        y = self.dropout(y)

        return y

    def __call__(self, x, masks=None):
        return self.forward(x, masks)

class Block(nn.Module):
    def __init__(self, embedding_dim, num_heads, dropout_rate, device=torch.device('cpu')):
        super().__init__()

        self.ln1 = nn.LayerNorm(embedding_dim, device=device)
        self.ln2 = nn.LayerNorm(embedding_dim, device=device)
        self.attention = CausalSelfAttention(embedding_dim, num_heads, dropout_rate, device=device)
        self.mlp = nn.Sequential(
            nn.Linear(embedding_dim, 4 * embedding_dim, device=device),
            nn.GELU(),
            nn.Linear(4 * embedding_dim, embedding_dim, device=device),
            nn.Dropout(dropout_rate))
        
    def forward(self, x, masks=None):
        x = self.ln1(x + self.attention(x, masks)) # add and norm
        x = self.ln2(x + self.mlp(x)) # add and norm

        return x

    def __call__(self, x, masks=None):
        return self.forward(x, masks)