import torch
from torch import nn
from ngf.utils.utils import MultiLayerPerceptron

class DampingNet(nn.Module):
    """
    torch module for damping parameterized by a neural network
    """
    def __init__(self, dim, feature_shape=0, feature_keys=None,
             hidden_units=(), activation=nn.Tanh(), normalize=False, 
             name='damping_net', device=torch.device('cpu')):
        '''
        :param dim: the dimension of input of the potential function gradient
                    (and hence the dimension of the potential gradient)
        :feature_shape: the dimension of features
        :feature_keys: the keys of features
        :param hidden units: the number of hidden layers for the potential gradient
        :param activation: activation function for the neural network
        :param normalize: whether to normalize input
        '''
        super(DampingNet, self).__init__()

        self.dim, self.units, self.activation = dim, hidden_units, activation
        self.damping_net = MultiLayerPerceptron(
                input_dim=2*dim+feature_shape, output_dim=1, 
                hidden_units=hidden_units,activation=activation, 
                device=device, name=name+'_mlp')

        if feature_keys is None:
            self.feature_keys = []
        else:
            self.feature_keys = feature_keys
        

    def __call__(self, q, qd, **features):
        '''
        :param q: generalized coordinate in batch
        :param qd: generalized velocity in batch
        :return: damping
        '''
        selected_features = {key: features[key] for key in self.feature_keys}
        state = torch.cat((q, qd)+tuple(selected_features.values()), axis=1)
        b = self.damping_net(state).reshape(-1, )
        damping = torch.einsum('b, bj -> bj', -b**2, qd)
        
        return damping

    def freeze(self):
        self.damping_net.freeze()
