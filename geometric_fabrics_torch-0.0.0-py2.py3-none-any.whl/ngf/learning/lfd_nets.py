import torch
from torch import nn
from abc import ABC, abstractmethod
from tqdm import tqdm
import time
import os
from ngf.learning.trainable_models import TrainableModel

class LfdNet(TrainableModel):
    """
    trainable tensorflow module for bc model
    """
    def __init__(
        self, cspace_dim, motion_policy=None, object_net=None, fd_net=None, delta_t=1., 
        q_lower_limit=None, q_upper_limit=None, qd_limit=None, loss='huber'):
        '''
        :param traj_nets: list of trajectory networks (TrajectoryNet)
        :param motion_policy: geometric motion policy (FabricGraph)
        :param belief_encoder: belief state encoder
        :param cspace_dim: configurations space dimension
        :param q_lower_limit: lower joint limit  
        :param q_upper_limit: upper joint limit 
        :param qd_limit: joint velocity limit
        :param loss: the type of loss function ('huber' or 'mse')
        '''
        super(LfdNet, self).__init__()

        self.cspace_dim = cspace_dim
        self.motion_policy = motion_policy
        self.object_net = object_net
        self.fd_net = fd_net
        self.q_lower_limit = q_lower_limit
        self.q_upper_limit = q_upper_limit
        self.qd_limit = qd_limit
        self.delta_t = delta_t

        if self.motion_policy is None:
            self.w_policy = 0
            self.w_object = 1
        else:
            self.w_policy = 1
            self.w_object = 0

        # creat the base loss function
        self.base_loss_function = None
        if loss == 'huber':
            self.base_loss_function = nn.HuberLoss()
        elif loss == 'mse':
            self.base_loss_function = nn.MSELoss()
        else:
            raise ValueError

    def loss(self, q, obj_states, **features):
        """
        compute the loss 
        :return: total loss
        """
        q_policy, obj_policy = self.rollout_policy(q, obj_states, **features)
        loss = self.w_policy*self.base_loss_function(q, q_policy) + self.w_object*self.base_loss_function(obj_states, obj_policy)

        return loss 

    def rollout_policy(self, q, obj_states, **features): 
        obj_policy = obj_states.clone()
        if self.object_net is not None:
            obj_policy = self.object_net(obj_states, **features)

        q_policy = q.clone()
        if self.motion_policy is not None:
            n_steps = q.shape[1]
            q_cur = q[:, 0]
            q_cur.requires_grad = True
            q_prev = torch.zeros_like(q_cur)

            q_policy = []
            q_policy.append(q_cur.unsqueeze(1))
            
            for i in range(n_steps-1):
                hand_features = dict(obj_states=obj_policy[:, i].detach())
                q_next = self.motion_policy(q_cur, q_cur-q_prev, **hand_features)
                q_policy.append(q_next.unsqueeze(1))
                q_prev = q_cur
                q_cur = q_next
        
            q_policy = torch.concat(q_policy, dim=1)

        return q_policy, obj_policy

    # def rollout_policy(self, q, obj_states, **features): 
    #     n_steps = q.shape[1]
    #     q_policy = q.clone()
    #     obj_policy = obj_states.clone()

    #     if self.object_net is not None:
    #         obj_policy = self.object_net(obj_states, **features)

    #     if self.motion_policy is not None:
    #         for i in range(n_steps-1):
    #             if i == 0:
    #                 q_prev = torch.zeros_like(q_policy[:, 0].clone())
    #             else:
    #                 q_prev = q_policy[:, i-1]
    #             q_cur = q_policy[:, i].clone()
    #             hand_features = dict(obj_states=obj_policy[:, i].detach())
    #             q_next = self.motion_policy(q_cur, q_cur-q_prev, **hand_features)
    #             q_policy[:, i+1] = q_next.clone()

    #     return q_policy, obj_policy

    # def rollout_policy(self, q, obj_states, **features): 
    #     n_steps = q.shape[1]
    #     q_policy = q.clone()
    #     obj_policy = obj_states.clone()
    #     for i in range(n_steps-1):
    #         if i == 0:
    #             q_prev = torch.zeros_like(q_policy[:, 0].clone())
    #         else:
    #             q_prev = q_policy[:, i-1].clone()
    #         q_cur = q_policy[:, i].clone()
    #         obj_cur = obj_policy[:, i].clone()
    #         if self.motion_policy is not None:
    #             hand_features = dict(obj_states=obj_cur)
    #             q_next = self.motion_policy(q_cur, q_cur-q_prev, **hand_features)
    #         else:
    #             q_next = q[:, i+1]

    #         if self.object_net is not None:
    #             obj_features = dict(q=q_cur)
    #             obj_next = self.object_net(obj_cur, **obj_features)
    #         else:
    #             obj_next = obj_states[:, i+1]

    #         q_policy[:, i+1] = q_next.clone()
    #         obj_policy[:, i+1] = obj_next.clone()

    #     return q_policy, obj_policy

    def clip_state(self, q):
        if self.q_lower_limit.device != q.device:
            self.q_lower_limit = self.q_lower_limit.to(q.device)
            self.q_upper_limit = self.q_upper_limit.to(q.device)
        return torch.max(torch.min(q, self.q_upper_limit), self.q_lower_limit)

