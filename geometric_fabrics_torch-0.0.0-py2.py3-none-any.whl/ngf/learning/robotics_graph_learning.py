import torch
from torch import nn
from ngf.geometric_fabrics.fabric_graph import FabricGraph
from ngf.learning.gmp_nets import GMPNet
from ngf.learning.rmp_nets import RMPNet
from ngf.learning.damping_nets import DampingNet
from ngf.learning.taskmap_nets import TaskMapNet

class ShadowNGFLearning(FabricGraph):
    """
    Fabric graph object for end effector behavior shaping
    with Shadow hand, the joint limit and default
    configuration policies are kept fixed, while the floor
    lifting and goal attractor policies are parameterized
    by neural networks
    """
    def __init__(self, base_link=None, eef_link=None, link_set=None, shadow_ngf_learning=None, normalize=False, root_shape=None, 
            dtype=torch.float32, device=torch.device('cpu'), timed=False, debug=False):
        """
        :params for NGF learning
        :param normalize: whether to normalize input
        :param dtype: data type of the graph
        :param timed: whether to time the compilation of the static graph
        :param debug: whether to print debug infos for GMPs
        :param name: name of the module
        """
        # set up robot
        cspace_dim = 24
        workspace_dim = 3

        self.dtype = dtype
        self.eef_link = eef_link
        self.workspace_dim = workspace_dim
        self.cspace_dim = cspace_dim
        self.shadow_ngf_learning = shadow_ngf_learning

        if self.shadow_ngf_learning is not None:
            if root_shape is None:
                root_shape = self.cspace_dim

            # geometry networks
            gmps = nn.ModuleList()
            for key, value in shadow_ngf_learning['geometries'].items():
                if 'cspace' in key:
                    value['dim'] = root_shape
                if 'tspace' in key:
                    value['dim'] = self.workspace_dim
                gmps.append(GMPNet(normalize=normalize, device= device,
                    dtype=dtype, debug=debug, timed=timed, name=key, **value))

            # damping networks
            damping_net = None
            if 'damping' in shadow_ngf_learning.keys():
                damping_net = DampingNet(root_shape, normalize=normalize, **shadow_ngf_learning['damping'], device=device)

            super().__init__(gmps=gmps, damping_net=damping_net, v2_energy=True, timed=timed)
            
            self.taskmap = None
            if 'taskmap' in shadow_ngf_learning.keys():
                self.taskmap = TaskMapNet(input_dim=root_shape, output_dim=self.workspace_dim, 
                    **shadow_ngf_learning['taskmap'], device=device)

    def forward_mapping(self, q, **features):
        """
        forward mapping from root node to leaf nodes given environment features
        --------------------------------------------
        :param q: root node coordinate
        :param features: environment features, lists/dicts, e.g. goals, obstacles, etc.
        :return xs: list of leaf node coordinates
        """
        x = []
        for key in self.shadow_ngf_learning['geometries'].keys():
            if 'cspace' in key:
                x.append(q)
            if 'tspace' in key and 'taskmap' in self.shadow_ngf_learning.keys():
                x.append(self.taskmap(q, **features))

        return x

class ShadowRMPLearning(FabricGraph):
    """
    Fabric graph object for end effector behavior shaping
    with Shadow hand, the joint limit and default
    configuration policies are kept fixed, while the floor
    lifting and goal attractor policies are parameterized
    by neural networks
    """
    def __init__(self, base_link=None, eef_link=None, link_set=None, shadow_rmp_learning=None, normalize=False, root_shape=None, 
            dtype=torch.float32, device=torch.device('cpu'), timed=False, debug=False):
        """
        :params for rmp learning
        :param normalize: whether to normalize input
        :param dtype: data type of the graph
        :param timed: whether to time the compilation of the static graph
        :param debug: whether to print debug infos for GMPs
        :param name: name of the module
        """
        # set up robot
        cspace_dim = 24
        workspace_dim = 3

        self.dtype = dtype
        self.eef_link = eef_link
        self.workspace_dim = workspace_dim
        self.cspace_dim = cspace_dim
        self.shadow_rmp_learning = shadow_rmp_learning

        if self.shadow_rmp_learning is not None:
            if root_shape is None:
                root_shape = self.cspace_dim

            # geometry networks
            rmps = nn.ModuleList()
            for key, value in shadow_rmp_learning['rmp'].items():
                if 'cspace' in key:
                    value['dim'] = root_shape
                if 'tspace' in key:
                    value['dim'] = self.workspace_dim
                rmps.append(RMPNet(normalize=normalize, device= device,
                    dtype=dtype, debug=debug, timed=timed, name=key, **value))

            # damping networks
            damping_net = None
            if 'damping' in shadow_rmp_learning.keys():
                damping_net = DampingNet(root_shape, normalize=normalize, **shadow_rmp_learning['damping'], device=device)

            super().__init__(gmps=rmps, damping_net=damping_net, energize=False, timed=timed)
            
            self.taskmap = None
            if 'taskmap' in shadow_rmp_learning.keys():
                self.taskmap = TaskMapNet(input_dim=root_shape, output_dim=self.workspace_dim, 
                    **shadow_rmp_learning['taskmap'], device=device)

    def forward_mapping(self, q, **features):
        """
        forward mapping from root node to leaf nodes given environment features
        --------------------------------------------
        :param q: root node coordinate
        :param features: environment features, lists/dicts, e.g. goals, obstacles, etc.
        :return xs: list of leaf node coordinates
        """
        x = []
        for key in self.shadow_rmp_learning['rmp'].keys():
            if 'cspace' in key:
                x.append(q)
            if 'tspace' in key and 'taskmap' in self.shadow_rmp_learning.keys():
                x.append(self.taskmap(q, **features))

        return x



