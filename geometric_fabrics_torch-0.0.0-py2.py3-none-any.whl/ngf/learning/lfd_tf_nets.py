import torch
from torch import nn
from ngf.learning.trainable_models import TrainableModel

class LfdTFNet(TrainableModel):
    """
    trainable tensorflow module for bc model
    """
    def __init__(
        self, cspace_dim, motion_policy=None, belief_net=None, delta_t=1., 
        q_lower_limit=None, q_upper_limit=None, qd_limit=None, loss='huber'):
        '''
        :param traj_nets: list of trajectory networks (TrajectoryNet)
        :param motion_policy: geometric motion policy (FabricGraph)
        :param belief_encoder: belief state encoder
        :param cspace_dim: configurations space dimension
        :param q_lower_limit: lower joint limit  
        :param q_upper_limit: upper joint limit 
        :param qd_limit: joint velocity limit
        :param loss: the type of loss function ('huber' or 'mse')
        '''
        super(LfdTFNet, self).__init__()

        self.cspace_dim = cspace_dim
        self.motion_policy = motion_policy
        self.belief_net = belief_net
        self.q_lower_limit = q_lower_limit
        self.q_upper_limit = q_upper_limit
        self.qd_limit = qd_limit
        self.delta_t = delta_t
        self.delta_t2 = delta_t**2

        if self.motion_policy is None:
            self.w_policy = 0
            self.w_object = 1
        else:
            self.w_policy = 1
            self.w_object = 0

        # creat the base loss function
        self.base_loss_function = None
        if loss == 'huber':
            self.base_loss_function = nn.HuberLoss()
        elif loss == 'mse':
            self.base_loss_function = nn.MSELoss()
        else:
            raise ValueError

    def loss(self, q, obj_states, **features):
        """
        compute the loss 
        :return: total loss
        """
        q_policy, _ = self.rollout_policy(q, obj_states, **features)
        loss = self.w_policy*self.base_loss_function(q, q_policy) 

        return loss 

    def rollout_policy(self, q, obj_states, **features): 
        batch_size, seq_len = obj_states.shape[0], obj_states.shape[1]
        init_q = q[:, 0:1, :].repeat((1, seq_len, 1))
        features['init_obj'] = obj_states[:, 0:1, :].repeat((1, seq_len, 1))
        belief_state, _ = self.belief_net(init_q, **features)

        q_prev = belief_state[:, :-1]
        q_cur = belief_state[:, 1:]
        qd = (q_cur - q_prev)/self.delta_t
        qdd = self.motion_policy(q_cur.reshape(batch_size*(seq_len-1), -1), qd.reshape(batch_size*(seq_len-1), -1), **{})
        qdd = qdd.reshape(batch_size, seq_len-1, -1)
        q_next = qdd*self.delta_t2 + 2*q_cur - q_prev
        q_policy = torch.concat((q[:, 0:1], q_next), dim=1)

        return q_policy, _

    def clip_state(self, q):
        if self.q_lower_limit.device != q.device:
            self.q_lower_limit = self.q_lower_limit.to(q.device)
            self.q_upper_limit = self.q_upper_limit.to(q.device)
        return torch.max(torch.min(q, self.q_upper_limit), self.q_lower_limit)

    def __call__(self, q0, obj0, **features):
        batch_size = features['num_traj']
        seq_len = features['time_horizon']
        init_q = q0.reshape(batch_size, 1, -1).repeat((1, seq_len, 1))
        features['init_obj'] = obj0.reshape(batch_size, 1, -1).repeat((1, seq_len, 1))
        belief_state, _ = self.belief_net(init_q, **features)

        q_prev = belief_state[:, :-1]
        q_cur = belief_state[:, 1:]
        qd = (q_cur - q_prev)/self.delta_t
        qdd = self.motion_policy(q_cur.reshape(batch_size*(seq_len-1), -1), qd.reshape(batch_size*(seq_len-1), -1), **{})
        qdd = qdd.reshape(batch_size, seq_len-1, -1)
        q_next = qdd*self.delta_t2 + 2*q_cur - q_prev
        q_policy = torch.concat((q0.reshape(batch_size, 1, -1), q_next), dim=1)

        return q_policy


