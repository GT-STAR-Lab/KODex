import torch
from torch import nn

class GeometryNet(nn.Module):
    """
    torch module for geometry generator parameterized by a neural network
    """
    def __init__(self, aux_net):
        '''
        :param aux_net: auxiliary network
        '''
        super(GeometryNet, self).__init__()
        self.aux_net = aux_net

    def __call__(self, x, xd, **features):
        '''
        :param x: generalized coordinate in batch
        :param xd: generalized velocity in batch
        :return: geometric generator
        '''
        aux_factor = self.aux_net(x, **features)
        # geometric generator
        geometry = torch.einsum('bi, bi -> b', xd, xd).reshape(-1, 1) * aux_factor
        
        return geometry

    def freeze(self):
        self.aux_net.freeze()