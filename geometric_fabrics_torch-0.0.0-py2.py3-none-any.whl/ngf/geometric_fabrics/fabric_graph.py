import torch
from torch import autograd
from torch import nn
from abc import ABC, abstractmethod
from ngf.controllers.controllers import LagrangianPolicyController
from ngf.utils.utils import ip, ipm, bmv, op, solve, batch_jacobian, batch_gradient, batch_gradient_safe
from ngf.utils.log_utils import timing


class FabricGraph(nn.Module, ABC):
    """
    torch module for pullback geometric fabrics and energize it at the root node
    """
    def __init__(
        self, gmps, damping_net=None, energize=True, v2_energy=False, B=0., B_min=0., L_alt=None, 
        target_pos_radius=None, desired_energy=None, speed_control=False, timed=False):
        """
        :param gmps: list of geometric motion policies at leaf nodes
        :param damping_net: damping network
        :param v2_energy: whether energize system with Euclidean energy Le = v^2/2
        :param B: Damping coefficient
        :param B_min: minimum damping coefficient
        :param target_pos_radius: distance from target pos where damping is applied to optimize \psi
        :param desired_energy: desired energy for particles to achieve (could be Euclidean speed)
        :param speed_control: whether speed control
        :param timed: whether to time the compilation of the static graph
        """
        super(FabricGraph, self).__init__()

        self.gmps = gmps
        self.damping_net = damping_net
        self.energize = energize
        self.v2_energy = v2_energy

        self.B = B
        self.B_min = B_min
        self.L_alt = L_alt
        if self.L_alt is not None:
            # Euler-Lagrangian (EL)
            self.EL_alt = LagrangianPolicyController(L=self.L_alt)

        self.target_pos_radius = target_pos_radius
        self.desired_energy = desired_energy
        self.speed_control = speed_control
        self.timed = timed

    @abstractmethod
    def forward_mapping(self, q, **features):
        """
        forward mapping from root node to leaf nodes given environment features
        --------------------------------------------
        :param q: root node coordinate
        :param features: environment features, lists/dicts, e.g. goals, obstacles, etc.
        :return xs: list of leaf node coordinates
        """

    def geometry_evals(self, xs, xds, **features):
        """
        evaluate the geometry at leaf nodes given environment
        features (optional, not used in the current version)
        --------------------------------------------
        :param xs: list of leaf node coordinates
        :param xds: list of leaf node generalized velocities
        :param features: environment features, lists/dicts, e.g. goals, obstacles, etc.
        :return f2s: list of leaf node force terms from geometry
        :return fes: list of leaf node force terms from E-L equation
        :return metrics: list of leaf node metrics from E-L equation
        :return grad_psis: list of leaf node potential gradients
        :return beta_gates: list of leaf node damping switching gates
        """
        f2s = []
        fes = []
        metrics = []
        grad_psis = []
        beta_gates = []

        # loop over leaf nodes and evaulate geometry at each leaf node
        for (x, xd, gmp) in zip(xs, xds, self.gmps):
            f2, fe, metric, grad_psi, beta_gate = gmp(x, xd, **features)
            f2s.append(f2)
            fes.append(fe)
            metrics.append(metric)
            grad_psis.append(grad_psi)
            beta_gates.append(beta_gate)
        return f2s, fes, metrics, grad_psis, beta_gates


    def get_geometric_pullbacks(self, q, qd, **features):
        """
        Given root node generalized coordinate q, velocity qd, and environment features,
        compute the pullback geometry at the root node
        --------------------------------------------
        :param q: root node coordinate
        :param qd: root node velocity
        :param features: environment features, lists/dicts, e.g. goals, obstacles, etc.
        :return f2: root node force term from geometry
        :return fe: root node force term from E-L equation
        :return M: root node metric from E-L equation
        :return grad_psi: root node potential gradients
        :return beta_gate: root node damping switching gate
        """

        q = q.clone().detach().requires_grad_(True)
        qd = qd.clone().detach().requires_grad_(True)
        if len(self.gmps) == 1:
            f2, fe, M, grad_psi, beta_gate = self.gmps[0](q, qd, root_only=True, **features)
        else:
            batch_size = q.shape[0]

            # compute the generalized coordinates x, velocities xd, and curvatures crv=Jdxd
            # at the leaf nodes
            with timing('forward pass', self.timed):
                # generalized coordinates through forward mapping
                xs = self.forward_mapping(q, **features)
                dummy_ones = [torch.ones_like(x, requires_grad=True) for x in xs]
                # sum of leaf node coordinates
                sum_xs = ip(dummy_ones, xs)
                sth = batch_gradient_safe(sum_xs, q, create_graph=True, retain_graph=True)
                # sum of leaf node velocities
                sum_xds = ip(sth, qd)
                # leaf node velocities
                z, *xds = batch_gradient_safe(sum_xds, (q, *dummy_ones), create_graph=self.training, retain_graph=self.training)
                # sum of leaf node curvature terms
                sum_crvs = ip(z, qd)
                # leaf node curvature terms 
                crvs = batch_gradient(sum_crvs, dummy_ones, create_graph=self.training, retain_graph=self.training) 

            # evaluate the geometries at the leaf nodes
            with timing('geometry evaluation', self.timed):
                f2_leaf, fe_leaf, metric_leaf, grad_psi_leaf, beta_gate_leaf = self.geometry_evals(xs, xds, **features)

            with timing('backward pass', self.timed):
                dummy_q = q + 0.
                dummy_xs = self.forward_mapping(dummy_q, **features)

                def jmx(qq):
                    xxs = self.forward_mapping(qq, **features)
                    # auxiliary variable
                    v = ipm(dummy_xs, xxs, metric_leaf)
                    return batch_gradient_safe(v, dummy_q, create_graph=True, retain_graph=self.training)

                def xf(qq):
                    xxs = self.forward_mapping(qq, **features)
                    # auxiliary variables
                    return ipm(xxs, crvs, metric_leaf), ip(xxs, f2_leaf), ip(xxs, fe_leaf), ip(xxs, grad_psi_leaf)

                wd, f2, fe, grad_psi = torch.autograd.functional.jacobian(xf, q + 0., create_graph=self.training) 
                # pullback force term from geometry generator f2_root=\sum J^T f2 + J^T M Jd qd
                f2 = f2 + wd
                # pullback force term from E-L equation fe_root=\sum J^T fe
                fe = fe + wd
                # pullback metrics M_root=\sum J^T M J
                M = batch_jacobian(jmx, q + 0., create_graph=self.training) 
                # pullback damping switch function beta_gate_root = \sum beta_gate,
                # reshape required when batch size is altered for e.g. barrier-type GMPs
                beta_gate_leaf = [torch.sum(bg.reshape(batch_size, -1), dim=1) for bg in beta_gate_leaf]
                beta_gate = sum(beta_gate_leaf).unsqueeze(-1)

        return f2, fe, M, grad_psi, beta_gate

    def get_forced_bent_finsler(self, q, qd, **features):
        """
        force a bent finsler representation with a potential
        qdd + phi2_le + M^-1 * grad_psi + B*qd = 0 is the original geometry generator
        --------------------------------------------
        :param q: root node coordinate
        :param q: root node velocity
        :param features: environment features, lists/dicts, e.g. goals, obstacles, etc.
        :return phi2_le_forced: energized acceleration policy
        """
        # get bent Finsler representation
        f2, fe, Me, grad_psi, _ = self.get_geometric_pullbacks(q, qd, **features)

        # resolve for accelerations
        if len(self.gmps) == 1:
            phi2 = f2
            qdd_grad_psi = grad_psi
        else:
            phi2 = solve(Me, f2)
            qdd_grad_psi = solve(Me, grad_psi)

        # energize
        if self.energize:
            if self.v2_energy:
                epsilon = 1e-15
                qd_ip = torch.einsum('bi, bi -> b', qd, qd).reshape(-1, 1)
                I_mm = torch.eye(Me.shape[1], Me.shape[1], dtype=Me.dtype, device=Me.device)
                phi2_le = bmv(I_mm - torch.div(op(qd, qd), torch.unsqueeze(qd_ip + epsilon, -1)), phi2)        
            else:
                # constant energy scalar
                alpha_le = self.get_constant_energy_scalar(q, qd, fe, Me, phi2)
                phi2_le = phi2 - torch.einsum('b, bj-> bj', alpha_le.reshape(-1, ), qd)
        else:
            phi2_le = phi2

        # get acceleration policy
        phi2_le_forced = phi2_le + qdd_grad_psi + (self.B + self.B_min) * qd

        if self.damping_net is not None:
            phi2_le_forced += self.damping_net(q, qd, **features)

        return phi2_le_forced


    def get_forced_bent_finsler_with_speed_control(self, q, qd, **features):
        """
        force a bent finsler representation with a potential, and do speed control
        by leveraging the geometric nullspace to regulate the velocity of a system
        in order to maintain a constant energy w.r.t. an alternative energy measure.
        Let alpha_le be such that xdd + Phi2 - alpha_le*xd maintains constant Le,
        alpha_alt^0 be such that xdd + Phi2 - alpha_alt^0*xd maintains a constant
        alternative energy Le^alt, and alpha_alt^Psi be such that
        xdd + Phi2 + Me_inv*grad_Psi - alpha_alt^Psi*xd maintains constant alternative
        energyt. Let alpha_alt be an interplation between alpha_alt^0 & alpha_alt^Psi,
        then we get the system as following:
            xdd + Phi2 + Me_inv*grad_psi - alpha_alt*xd + B*xd = 0
        return Phi2_interp = Phi2 + Me_inv*grad_psi - alpha_alt*xd + B*xd
        --------------------------------------------
        :param q: root node coordinate
        :param q: root node velocity
        :param features: environment features, lists/dicts, e.g. goals, obstacles, etc.
        :return phi2_interp: energized acceleration policy
        """
        # run get geometric pullbacks to get f2, fe, Me, grad_psi, beta_gate
        f2, fe, Me, grad_psi, beta_gate = self.get_geometric_pullbacks(q, qd, **features)

        # resolve for accelerations
        phi2 = solve(Me, f2)
        qdd_grad_psi = solve(Me, grad_psi)

        # calculate constant energy scalars
        alpha_Le, alpha_alt, alpha_alt_psi = \
            self.get_constant_energy_scalars(q, qd, phi2, fe, Me, qdd_grad_psi)

        # energy switching gate
        zeta_gate = None
        if self.desired_energy is not None:
            zeta_gate = self.get_energy_gate(q, qd)
        else:
            zeta_gate = torch.zeros((q.shape[0],), device = q.device)

        # alpha
        alpha_alt = zeta_gate * alpha_alt + (1. - zeta_gate) * alpha_alt_psi

        # damping
        B_lb = torch.maximum(alpha_alt - alpha_Le, torch.zeros_like(alpha_Le))
        B = beta_gate * self.B + B_lb + self.B_min

        # Find alpha to maintain constant L_alt energy under forcing Psi
        phi2_interp = phi2 + qdd_grad_psi - torch.einsum('bi, bj-> bj', alpha_alt, qd) + torch.einsum('bi, bj-> bj', B, qd)

        if self.damping_net is not None:
            phi2_interp += self.damping_net(q, qd, **features)

        return phi2_interp

    def get_constant_energy_scalar(self, q, qd, f, M, qdd_geom, epsilon=1e-16):
        """
        calculate energy coefficient which can maintain constant energy Le while being
        consistent with the original geometry Phi2
            alpha = inv(xd^T*Me*xd)*[xd^T*Me*Phi2 - xd^T*fe]
        Me and fe are from Lagrangian energy Le, and Me = M, fe = -f
        :param q: root node coordinate
        :param qd: root node velocity
        :param f: force term in E-L equation, expressed on the RHS of E-L
        :param M: mass term in E-L equation
        :param xdd_geom: acceleration which could include term from the original geometry
                generator phi2, and also acceleration coming for the potential force M_inv*grad_psi
        :param epsilon: small value to add to avoid divided by zero
        :return alpha: alpha to maintain constant Le energy
        """
        # Lagrangian policy class calculates the force term expressed in the RHS of the
        # E-L equation as M*xdd = f, however, in geometry generator equation, we want
        # it be expressed on the LHS as xdd + M_inv*(-f) = 0, therefore the sign is flipped
        # in the equation.
        ip_qd_f = torch.unsqueeze(torch.einsum('bi, bi -> b', qd, f).reshape(-1, 1), -1)
        alpha = torch.div((ipm(qd, qdd_geom, M) - ip_qd_f), (ipm(qd, qd, M) + epsilon)).reshape(-1, 1)

        return alpha

    def get_constant_energy_scalars(self, q, qd, phi2, fe, Me, qdd_grad_psi):
        """
        calculate all the energy coefficients which can maintain different constant energies
        Let alpha_le be such that xdd + Phi2 - alpha_le*xd = 0 maintains constant Le,
        alpha_alt^0 be such that xdd + Phi2 - alpha_alt^0*xd = 0 maintains a constant
        alternative energy Le^alt, and alpha_alt^Psi be such that
        xdd + Phi2 + Me_inv*grad_Psi - alpha_alt^Psi*xd = 0 maintains constant alternative
        energy under potential force grad_Psi.
        ---------------------------------------
        :param q: root node coordinate
        :param qd: root node velocity
        :param phi2: term from original geometry generator
        :param fe: force term in E-L equation derived from Le, expressed on the RHS of E-L
        :param Me: mass term in E-L equation derived from Le
        :param xdd_grad_psi: acceleration resulted from potential force
        :return alpha_Le: alpha to maintain constant Le energy
        :return alpha_alt_0: alpha to maintain constant L_alt energy
        :return alpha_alt_psi: alpha to maintain constant L_alt energy under forcing psi
        """
        # find alpha to maintain constant Le energy
        alpha_Le = self.get_constant_energy_scalar(q, qd, fe, Me, phi2)

        alpha_alt_0 = torch.zeros(q.shape[0], device = q.device)
        alpha_alt_psi = torch.zeros(q.shape[0], device = q.device)

        if self.L_alt is not None:
            # find alpha to maintain constant L_alt energy
            f_alt, M_alt = self.EL_alt.calc_force_and_mass(q, qd)
            alpha_alt_0 = self.get_constant_energy_scalar(q, qd, f_alt, M_alt, phi2)

            # find alpha to maintain constant L_alt energy under forcing Psi
            alpha_alt_psi = self.get_constant_energy_scalar(q, qd, f_alt, M_alt, phi2 + qdd_grad_psi)

        return alpha_Le, alpha_alt_0, alpha_alt_psi

    def get_energy_gate(self, q, qd):
        """
        compute the energy switching
        ---------------------------------------
        :param q: root node coordinate
        :param qd: root node velocity
        :return zeta_gate: energy switching gate
        """
        energy = self.EL_alt.L(q, qd)
        zeta_gate = torch.zeros((q.shape[0], 1), device = q.device)
        zeta_gate = ((1./self.desired_energy ** 2) * (energy - self.desired_energy) ** 2)
        zeta_gate = torch.where(energy <= self.desired_energy, zeta_gate, 0.)

        return zeta_gate

    def __call__(self, q, qd, **features):
        """
        Pullback geometry and energize at the root
        --------------------------------------------
        :param q: root node coordinate
        :param q: root node velocity
        :param features: environment features, lists/dicts, e.g. goals, obstacles, etc.
        :return qdd: root node acceleration
        """
        if self.speed_control:
            qdd = -self.get_forced_bent_finsler_with_speed_control(q, qd, **features)
        else:
            qdd = -self.get_forced_bent_finsler(q, qd, **features)
        return qdd

    def freeze(self):
        for gmp in self.gmps:
            gmp.freeze()
        self.damping_net.freeze() 