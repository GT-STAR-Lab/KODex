from ngf.learning.belief_autoencoder import BeliefAutoEncoder
from ngf.learning.robotics_graph_learning import ShadowRMPLearning
from ngf.learning.robotics_graph_learning import ShadowNGFLearning
from ngf.configs.training_config_copemann import config

import os
import torch
from torch import nn

class LfDModel(nn.Module):
    def __init__(self, batch_size=1, time_horizon=100, dt=0.01, network_size='median', policy_name="ngf", task_name='pen'):
        super().__init__()

        self.batch_size = batch_size
        self.time_horizon = time_horizon
        self.delta_t = dt
        self.delta_t2 = dt**2
        self.policy_name = policy_name
        self.task_name = task_name

        self.robot_name = "shadow"
        base_link = 'forearm'
        eef_link = 'mftip'
        link_set = ['fftip', 'mftip', 'rftip', 'lftip', 'thtip']

        if self.task_name == "pen":
            robot_dim = 24
            object_dim = 12
        if self.task_name == "reloc":
            robot_dim = 30
            object_dim = 12
        if self.task_name == "door":
            robot_dim = 28
            object_dim = 7
        if self.task_name == "hammer":
            robot_dim = 26
            object_dim = 15

        # --------------------------------------------------------------------------------------
        # motion policy
        if self.policy_name == "ngf":
            if network_size == 'small':
                config['shadow_ngf_learning']['geometries']['cspace_geometry']['hidden_units'] = [64, 32]
                config['shadow_ngf_learning']['damping']['hidden_units'] = [64, 32]
                config['belief_net']['embedding_dim'] = 32
            if network_size == 'median':
                config['shadow_ngf_learning']['geometries']['cspace_geometry']['hidden_units'] = [128, 64]
                config['shadow_ngf_learning']['damping']['hidden_units'] = [128, 64]
                config['belief_net']['embedding_dim'] = 64
            if network_size == 'large':
                config['shadow_ngf_learning']['geometries']['cspace_geometry']['hidden_units'] = [256, 128]
                config['shadow_ngf_learning']['damping']['hidden_units'] = [256, 128]
                config['belief_net']['embedding_dim'] = 128
            self.motion_policy = ShadowNGFLearning(base_link=base_link, eef_link=eef_link, link_set=link_set, root_shape=robot_dim,
                shadow_ngf_learning=config['shadow_ngf_learning'], dtype=config['dtype'], device=config['device'])
        if self.policy_name == "rmp":
            self.motion_policy =  ShadowRMPLearning(base_link=base_link, eef_link=eef_link, link_set=link_set, root_shape=robot_dim,
                shadow_rmp_learning=config['shadow_rmp_learning'], dtype=config['dtype'], device=config['device'])

        # --------------------------------------------------------------------------------------
        # belief state auto-encoder
        config['belief_net']['feature_shape'] = object_dim
        config['belief_net']['belief_dim'] = robot_dim
        self.belief_net = BeliefAutoEncoder(action_dim=robot_dim, device=config['device'], **config['belief_net'])

    def generate_traj(self, batch):
        batch_size = self.batch_size
        seq_len = self.time_horizon
        q0 = batch['hand_joint']
        obj0 = batch['object_states']
        init_q = q0.reshape(batch_size, 1, -1).repeat((1, seq_len, 1))
        features = {'init_obj': obj0.reshape(batch_size, 1, -1).repeat((1, seq_len, 1))}
        belief_state, _ = self.belief_net(init_q, **features)

        q_prev = belief_state[:, :-1]
        q_cur = belief_state[:, 1:]
        qd = (q_cur - q_prev)/self.delta_t
        qdd = self.motion_policy(q_cur.reshape(batch_size*(seq_len-1), -1), qd.reshape(batch_size*(seq_len-1), -1), **{})
        qdd = qdd.reshape(batch_size, seq_len-1, -1)
        q_next = qdd*self.delta_t2 + 2*q_cur - q_prev
        q_policy = torch.concat((q0.reshape(batch_size, 1, -1), q_next), dim=1)

        return q_policy

    def forward(self, input_dict):
        return self.generate_traj(input_dict)

    def load_networks(self, model_dir, num_demo=250, trial_num=1):
        filename = self.policy_name + '_' + self.task_name + '_' + str(num_demo) + '_' + str(trial_num) + '.pt'
        if os.path.exists(model_dir):
            # load model
            print('load model from', os.path.join(model_dir, filename))
            pretrained_models = torch.load(os.path.join(model_dir, filename))

            # 1. filter out unnecessary keysx
            policy_model = self.motion_policy.state_dict()
            pretrained_policy_model = {}

            belief_model = self.belief_net.state_dict()
            pretrained_belief_model = {}
            for key, val in pretrained_models.items():
                if 'motion_policy' in key:
                    for k in policy_model.keys():
                        if k in key:
                            pretrained_policy_model[k] = val

                if 'belief_net' in key:
                    for k in belief_model.keys():
                        if k in key:
                            pretrained_belief_model[k] = val

            # 2. overwrite entries in the existing state dict
            policy_model.update(pretrained_policy_model) 
            belief_model.update(pretrained_belief_model) 

            # 3. load the new state dict
            self.motion_policy.load_state_dict(policy_model)
            self.belief_net.load_state_dict(belief_model)
        else:
            print("Model path does not exist!!!!!!!!!!!!")