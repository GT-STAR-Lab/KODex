from contextlib import contextmanager
import time

@contextmanager
def timing(msg, verbose=True):
    """
    time code segments
    """
    if verbose:
        # print("\t---------------------------------")
        print("\t[Timer] %s started..." % (msg))
        tstart = time.time()
        yield
        print("\t[Timer] %s done in %.3f seconds" % (msg, time.time() - tstart))
        print("\t---------------------------------")
    else:
        yield