from this import d
import torch
from torch import nn
from torch.utils.data import DataLoader
import torch.optim as optim
from torch.optim import lr_scheduler
from warmup_scheduler import GradualWarmupScheduler
import numpy as np
import time
import os
import pickle


def safe_filesystem_op(func, *args, **kwargs):
    """
    This is to prevent spurious crashes related to saving checkpoints or restoring from checkpoints in a Network
    Filesystem environment (i.e. NGC cloud or SLURM)
    """
    num_attempts = 5
    for attempt in range(num_attempts):
        try:
            return func(*args, **kwargs)
        except Exception as exc:
            print(f'Exception {exc} when trying to execute {func} with args:{args} and kwargs:{kwargs}...')
            wait_sec = 2 ** attempt
            print(f'Waiting {wait_sec} before trying again...')
            time.sleep(wait_sec)
    raise RuntimeError(f'Could not execute {func}, give up after {num_attempts} attempts...')

def safe_load(filename):
    return safe_filesystem_op(torch.load, filename)

def load_checkpoint(filename):
    print("=> loading checkpoint '{}'".format(filename))
    state = safe_load(filename)
    return state

if __name__ == '__main__':
    package_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')
    filename = 'last_AllegroHand_ep_5001.pth'
    model_path = os.path.join(package_path, 'model', 'gym', filename)

    checkpoint = load_checkpoint(model_path)
    











