import torch
import numpy as np
from matplotlib import pyplot as plt
import os

def plot_eef_traj_2D(traj, ls, color, lw=2, legend=None):
    plt.plot(traj[:, 0], traj[:, 1], linestyle=ls, linewidth=lw, color=color, label=legend)
    plt.grid(which='major', linestyle='--', linewidth='0.5', color='gray')	
    plt.scatter(traj[0, 0], traj[0, 1], color='green', marker='o')
    plt.scatter(traj[-1, 0], traj[-1, 1], color='red', marker='x')

def plot_eef_traj_3D(traj, ls, color, lw=2, ax_handle=None, legend=None):
	if ax_handle is None:
		ax = plt.gca(projection='3d')
	else:
		ax = ax_handle

	ax.plot3D(traj[:, 0], traj[:, 1], traj[:, 2], linestyle=ls, linewidth=lw, color=color, label=legend)
	ax.scatter3D(traj[0, 0], traj[0, 1], traj[0, 2], color='green', marker='o', linewidth=lw)
	ax.scatter3D(traj[-1, 0], traj[-1, 1], traj[-1, 2], color='red', marker='x', linewidth=lw)

def plot_sub(t, q, q_ref, plot_path):
    _, axs = plt.subplots(q.shape[1], 1, sharex='col',
                        gridspec_kw={'hspace': 0, 'wspace': 0})
    axs[-1].set(xlabel='x')
    for j in range(q.shape[1]):
        axs[j].set(ylabel='y'+str(j+1))
        axs[j].plot(t, q[:, j], color='r')
        axs[j].plot(t, q_ref[:, j], color='g')
        axs[j].grid(which='major', linestyle='--', linewidth='0.5', color='gray')
    
    plt.savefig(plot_path, bbox_inches='tight')
    plt.close()

def wrap2pi(q):
    q = torch.arctan2(torch.sin(q), torch.cos(q))
    return q

def plot_policy_rollout(batch, demo_dir, lfd_net, plot_idx=0, eef_task_map=None, device=torch.device('cpu')):
    dt = batch['dt']
    t = batch['t']
    q = batch['q']

    if 'qd' in batch.keys():
        qd = batch['qd']
        qdd = batch['qdd']
    else:
        qd = q
        qdd = q

    num_traj, n_steps, cspace_dim = q.shape[0], q.shape[1], q.shape[2]
    q_policy, qd_policy, qdd_policy = lfd_net.rollout_policy(**batch)
    if eef_task_map is not None:
        eef = eef_task_map(q.reshape(num_traj*n_steps, -1)).reshape(num_traj, n_steps, -1)
        eef_policy = eef_task_map(q_policy.reshape(num_traj*n_steps, -1)).reshape(num_traj, n_steps, -1)

    if device==torch.device('cuda'):
        dt = dt.detach().cpu().numpy()
        t = t.detach().cpu().numpy()
        q = q.detach().cpu().numpy()
        qd = qd.detach().cpu().numpy()
        qdd = qdd.detach().cpu().numpy()
        q_policy = q_policy.detach().cpu().numpy()
        qd_policy = qd_policy.detach().cpu().numpy()
        qdd_policy = qdd_policy.detach().cpu().numpy()
        if eef_task_map is not None:
            eef = eef.detach().cpu().numpy()
            eef_policy = eef_policy.detach().cpu().numpy()
    else:
        dt = dt.detach().numpy()
        t = t.detach().numpy()
        q = q.detach().numpy()
        qd = qd.detach().numpy()
        qdd = qdd.detach().numpy()
        q_policy = q_policy.detach().numpy()
        qd_policy = qd_policy.detach().numpy()
        qdd_policy = qdd_policy.detach().numpy()
        if eef_task_map is not None:
            eef = eef.detach().numpy()
            eef_policy = eef_policy.detach().numpy()

    num_nonzeros = np.squeeze(np.count_nonzero(dt, axis=1))
    if len(num_nonzeros.shape) == 0:
        num_nonzeros = [num_nonzeros]

    for i in range(num_traj):
        n_steps = num_nonzeros[i]
        t_trimmed = t[i, :n_steps, 0]
        q_trimmed = q[i, :n_steps]
        qd_trimmed = qd[i, :n_steps]
        qdd_trimmed = qdd[i, :n_steps]
        q_policy_trimmed = q_policy[i, :n_steps]
        qd_policy_trimmed = qd_policy[i, :n_steps]
        qdd_policy_trimmed = qdd_policy[i, :n_steps]
        if eef_task_map is not None:
            eef_trimmed = eef[i, :n_steps]
            eef_policy_trimmed = eef_policy[i, :n_steps]

        if cspace_dim == 23:
            num_r = 3
            num_c = 7
        
        if cspace_dim == 16:
            num_r = 3
            num_c = 5

        _, axs = plt.subplots(num_r, num_c, sharex='col', sharey='row',
                        gridspec_kw={'hspace': 0, 'wspace': 0})
        for k in range(num_r):
            q_test = q_policy_trimmed[:, k*num_c:(k+1)*num_c]
            q_ref = q_trimmed[:, k*num_c:(k+1)*num_c]

            for j in range(num_c):
                axs[k, 0].set(ylabel='q')
                axs[2, j].set(xlabel='t')
                axs[k, j].plot(t_trimmed, q_ref[:, j], color='g')
                axs[k, j].plot(t_trimmed, q_test[:, j], color='r')                    
                axs[k, j].grid(which='major', linestyle='--', linewidth='0.5', color='gray')
                
        plot_name = 'plot_traj_' + str(plot_idx+i+1) + '.pdf'
        plot_path = os.path.join(demo_dir, plot_name)
        plt.savefig(plot_path, bbox_inches='tight')
        plt.close()

        if eef_task_map is not None:
            plot_eef_traj_3D(eef_trimmed, ls='-', color='g')
            plot_eef_traj_3D(eef_policy_trimmed, ls='-', color='r')

            plot_name = 'plot_traj_eef_' + str(plot_idx+i+1) + '.pdf'
            plot_path = os.path.join(demo_dir, plot_name)
            plt.savefig(plot_path, bbox_inches='tight')
            plt.close()

def plot_policy_allegro(batch, demo_dir, lfd_net, plot_idx=0, device=torch.device('cpu')):
    actions = batch['actions']

    num_traj, num_steps = actions.shape[0], actions.shape[1]
    # actions_policy = lfd_net.get_action(**batch)
    actions_policy = lfd_net.rollout_policy(**batch)

    if device==torch.device('cuda'):
        actions = actions.detach().cpu().numpy()
        actions_policy = actions_policy.detach().cpu().numpy()
    else:
        actions = actions.detach().numpy()
        actions_policy = actions_policy.detach().numpy()

    t = torch.arange(num_steps)
    for k in range(num_traj):
        num_r = 4
        num_c = 4

        _, axs = plt.subplots(num_r, num_c, sharex='col', sharey='row',
                        gridspec_kw={'hspace': 0, 'wspace': 0})
        for i in range(num_r):
            for j in range(num_c):
                axs[i, 0].set(ylabel='q')
                axs[num_r-1, j].set(xlabel='t')
                jn = i*num_c + j
                axs[i, j].plot(t, actions[k, :, jn], color='g')
                axs[i, j].plot(t, actions_policy[k, :, jn], color='c')
                axs[i, j].plot(t, actions[k, :, jn] - actions_policy[k, :, jn], color='r')                    
                axs[i, j].grid(which='major', linestyle='--', linewidth='0.5', color='gray')
                
        plot_name = 'plot_traj_' + str(plot_idx+k+1) + '.pdf'
        plot_path = os.path.join(demo_dir, plot_name)
        plt.savefig(plot_path, bbox_inches='tight')
        plt.close()

def plot_policy_shadow(batch, demo_dir, lfd_net, plot_idx=0, device=torch.device('cpu')):
    actions = batch['actions']

    num_traj, num_steps = actions.shape[0], actions.shape[1]
    actions_policy = lfd_net.get_action(**batch)
    # actions_policy = lfd_net.rollout_policy(**batch)

    if device==torch.device('cuda'):
        actions = actions.detach().cpu().numpy()
        actions_policy = actions_policy.detach().cpu().numpy()
    else:
        actions = actions.detach().numpy()
        actions_policy = actions_policy.detach().numpy()

    t = torch.arange(num_steps)
    for k in range(num_traj):
        num_r = 4
        num_c = 5

        _, axs = plt.subplots(num_r, num_c, sharex='col', sharey='row',
                        gridspec_kw={'hspace': 0, 'wspace': 0})
        for i in range(num_r):
            for j in range(num_c):
                axs[i, 0].set(ylabel='q')
                axs[num_r-1, j].set(xlabel='t')
                jn = i*num_c + j
                axs[i, j].plot(t, actions[k, :, jn], color='g')
                axs[i, j].plot(t, actions_policy[k, :, jn], color='c')
                axs[i, j].plot(t, actions[k, :, jn] - actions_policy[k, :, jn], color='r')                    
                axs[i, j].grid(which='major', linestyle='--', linewidth='0.5', color='gray')
                
        plot_name = 'plot_traj_' + str(plot_idx+k+1) + '.pdf'
        plot_path = os.path.join(demo_dir, plot_name)
        plt.savefig(plot_path, bbox_inches='tight')
        plt.close()

def plot_hand_koopmann(batch, demo_dir, lfd_net, plot_idx=0, device=torch.device('cpu')):
    q = batch['q']

    num_traj, num_steps = q.shape[0], q.shape[1]
    q_policy, _ = lfd_net.rollout_policy(**batch)

    if device==torch.device('cuda'):
        q = q.detach().cpu().numpy()
        q_policy = q_policy.detach().cpu().numpy()
    else:
        q = q.detach().numpy()
        q_policy = q_policy.detach().numpy()

    t = torch.arange(num_steps)
    for k in range(num_traj):
        num_r = 4
        num_c = 6

        _, axs = plt.subplots(num_r, num_c, sharex='col', sharey='row',
                        gridspec_kw={'hspace': 0, 'wspace': 0})
        for i in range(num_r):
            for j in range(num_c):
                axs[i, 0].set(ylabel='q')
                axs[num_r-1, j].set(xlabel='t')
                jn = i*num_c + j
                axs[i, j].plot(t, q[k, :, jn], color='g')
                axs[i, j].plot(t, q_policy[k, :, jn], color='c')
                # axs[i, j].plot(t, q[k, :, jn] - q_policy[k, :, jn], color='r')                    
                axs[i, j].grid(which='major', linestyle='--', linewidth='0.5', color='gray')
                
        plot_name = 'plot_hand_traj_' + str(plot_idx+k+1) + '.pdf'
        plot_path = os.path.join(demo_dir, plot_name)
        plt.savefig(plot_path, bbox_inches='tight')
        plt.close()

def plot_object_koopmann(batch, demo_dir, lfd_net, plot_idx=0, device=torch.device('cpu')):
    q = batch['obj_states']

    num_traj, num_steps = q.shape[0], q.shape[1]
    _, q_policy = lfd_net.rollout_policy(**batch)

    if device==torch.device('cuda'):
        q = q.detach().cpu().numpy()
        q_policy = q_policy.detach().cpu().numpy()
    else:
        q = q.detach().numpy()
        q_policy = q_policy.detach().numpy()

    t = torch.arange(num_steps)
    for k in range(num_traj):
        num_r = 2
        num_c = 3

        _, axs = plt.subplots(num_r, num_c, sharex='col', sharey='row',
                        gridspec_kw={'hspace': 0, 'wspace': 0})
        for i in range(num_r):
            for j in range(num_c):
                axs[i, 0].set(ylabel='q')
                axs[num_r-1, j].set(xlabel='t')
                jn = i*num_c + j
                axs[i, j].plot(t, q[k, :, jn], color='g')
                axs[i, j].plot(t, q_policy[k, :, jn], color='c')
                # axs[i, j].plot(t, q[k, :, jn] - q_policy[k, :, jn], color='r')                    
                axs[i, j].grid(which='major', linestyle='--', linewidth='0.5', color='gray')
                
        plot_name = 'plot_object_traj_' + str(plot_idx+k+1) + '.pdf'
        plot_path = os.path.join(demo_dir, plot_name)
        plt.savefig(plot_path, bbox_inches='tight')
        plt.close()


    