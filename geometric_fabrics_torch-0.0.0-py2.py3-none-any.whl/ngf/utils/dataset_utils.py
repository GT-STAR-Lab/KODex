from torch.utils.data import TensorDataset, Dataset
import torch

class CspaceDataset(Dataset):
	def __init__(self, dt, t, q, qd, qdd, start, goal):
		self.dt = dt
		self.t = t
		self.q = q
		self.qd = qd
		self.qdd = qdd
		self.start = start
		self.goal = goal

	def __getitem__(self, index):
		dt_batch = self.dt[index]
		t_batch = self.t[index]
		q_batch = self.q[index]
		qd_batch = self.qd[index]
		qdd_batch = self.qdd[index]
		start_batch = self.start[index]
		goal_batch = self.goal[index]
		return dt_batch, t_batch, q_batch, qd_batch, qdd_batch, start_batch, goal_batch

	def __len__(self):
		return self.q.size(0)

class DexlearnDataset(Dataset):
	def __init__(self, dt, t, q, qd, qdd, goal, init_pose, obj_ids):
		self.dt = dt
		self.t = t
		self.q = q
		self.qd = qd
		self.qdd = qdd
		self.goal = goal
		self.init_pose = init_pose
		self.obj_ids = obj_ids

	def __getitem__(self, index):
		dt_batch = self.dt[index]
		t_batch = self.t[index]
		q_batch = self.q[index]
		qd_batch = self.qd[index]
		qdd_batch = self.qdd[index]
		goal_batch = self.goal[index]
		init_pose_batch = self.init_pose[index]
		obj_ids_batch = self.obj_ids[index]

		return dt_batch, t_batch, q_batch, qd_batch, qdd_batch, goal_batch, \
			init_pose_batch, obj_ids_batch

	def __len__(self):
		return self.q.size(0)

class DexlearnDiscreteDataset(Dataset):
	def __init__(self, dt, t, q, delta_q, q_prev, q_next, goal, init_pose, obj_ids):
		self.dt = dt
		self.t = t
		self.q = q
		self.delta_q = delta_q
		self.q_prev = q_prev
		self.q_next = q_next
		self.goal = goal
		self.init_pose = init_pose
		self.obj_ids = obj_ids

	def __getitem__(self, index):
		dt_batch = self.dt[index]
		t_batch = self.t[index]
		q_batch = self.q[index]
		delta_q_batch = self.delta_q[index]
		q_prev_batch = self.q_prev[index]
		q_next_batch = self.q_next[index]
		goal_batch = self.goal[index]
		init_pose_batch = self.init_pose[index]
		obj_ids_batch = self.obj_ids[index]

		return dt_batch, t_batch, q_batch, delta_q_batch, q_prev_batch, q_next_batch, \
			goal_batch, init_pose_batch, obj_ids_batch

	def __len__(self):
		return self.q.size(0)

class AllegroDatasetSim2Real(Dataset):
	def __init__(self, actions, q_prev, q_cur, q_measured, qd_measured, point_clouds, point_clouds_noisy, cube_pose, goal_pose, masks):
		self.actions = actions
		self.q_prev = q_prev
		self.q_cur = q_cur
		self.q_measured = q_measured
		self.qd_measured = qd_measured
		self.point_clouds = point_clouds
		self.point_clouds_noisy = point_clouds_noisy
		self.cube_pose = cube_pose
		self.goal_pose = goal_pose
		self.masks = masks

	def __getitem__(self, index):
		actions_batch = self.actions[index]
		q_prev_batch = self.q_prev[index]
		q_cur_batch = self.q_cur[index]
		q_measured_batch = self.q_measured[index]
		qd_measured_batch = self.qd_measured[index]
		point_clouds_batch = self.point_clouds[index]
		point_clouds_noisy_batch = self.point_clouds_noisy[index]
		cube_pose_batch = self.cube_pose[index]
		goal_pose_batch = self.goal_pose[index]
		masks_batch = self.masks[index]

		return actions_batch, q_prev_batch, q_cur_batch, q_measured_batch, qd_measured_batch, \
			point_clouds_batch, point_clouds_noisy_batch, cube_pose_batch, goal_pose_batch, masks_batch

	def __len__(self):
		return self.actions.size(0)

class AllegroDataset(Dataset):
	def __init__(self, actions, q_prev, q_cur, q_measured, qd_measured, point_clouds, cube_pose, goal_pose, masks, reset_buf):
		self.actions = actions
		self.q_prev = q_prev
		self.q_cur = q_cur
		self.q_measured = q_measured
		self.qd_measured = qd_measured
		self.point_clouds = point_clouds
		self.cube_pose = cube_pose
		self.goal_pose = goal_pose
		self.masks = masks
		self.reset_buf = reset_buf

	def __getitem__(self, index):
		actions_batch = self.actions[index]
		q_prev_batch = self.q_prev[index]
		q_cur_batch = self.q_cur[index]
		q_measured_batch = self.q_measured[index]
		qd_measured_batch = self.qd_measured[index]
		point_clouds_batch = self.point_clouds[index]
		cube_pose_batch = self.cube_pose[index]
		goal_pose_batch = self.goal_pose[index]
		masks_batch = self.masks[index]
		reset_buf_batch = self.reset_buf[index]

		return actions_batch, q_prev_batch, q_cur_batch, q_measured_batch, qd_measured_batch, \
			point_clouds_batch, cube_pose_batch, goal_pose_batch, masks_batch, reset_buf_batch

	def __len__(self):
		return self.actions.size(0)

class ShadowDataset(Dataset):
	def __init__(self, actions, q_cur, q_measured, qd_measured, cube_pose, goal_pose, 
			object_points, object_normals, target_points, target_normals):
		self.actions = actions
		self.q_cur = q_cur
		self.q_measured = q_measured
		self.qd_measured = qd_measured
		self.cube_pose = cube_pose
		self.goal_pose = goal_pose
		self.object_points = object_points
		self.object_normals = object_normals
		self.target_points = target_points
		self.target_normals = target_normals

	def __getitem__(self, index):
		actions_batch = self.actions[index]
		q_cur_batch = self.q_cur[index]
		q_measured_batch = self.q_measured[index]
		qd_measured_batch = self.qd_measured[index]
		cube_pose_batch = self.cube_pose[index]
		goal_pose_batch = self.goal_pose[index]
		object_points_batch = self.object_points[index]
		object_normals_batch = self.object_normals[index]
		target_points_batch = self.target_points[index]
		target_normals_batch = self.target_normals[index]

		return actions_batch, q_cur_batch, q_measured_batch, qd_measured_batch, cube_pose_batch, goal_pose_batch,\
			 object_points_batch, object_normals_batch, target_points_batch, target_normals_batch

	def __len__(self):
		return self.actions.size(0)

class KoopmannDataset(Dataset):
	def __init__(self, q, qd, obj_states):
		self.q = q
		self.qd = qd
		self.obj_states = obj_states

	def __getitem__(self, index):
		q_batch = self.q[index]
		qd_batch = self.qd[index]
		obj_states_batch = self.obj_states[index]

		return q_batch, qd_batch, obj_states_batch

	def __len__(self):
		return self.q.size(0)
