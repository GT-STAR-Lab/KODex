import torch
from torch import nn
from torch import autograd
from collections.abc import Iterable, Sized

def ip(x, y, reduce='sum'):
    """
    inner product between vectors or list(s) of tensors
    """
    assert reduce == 'sum' or reduce is None

    # if both inputs are tensors, return inner product
    if isinstance(x, torch.Tensor) and isinstance(y, torch.Tensor):
        # assert x.shape == y.shape
        return torch.sum(x * y)
    # if one is tensor, the other is a list of tensors, return the sum (reduction=sum)
    # or a list (reduction=None) of inner products
    elif isinstance(x, torch.Tensor) and not isinstance(y, torch.Tensor):
        assert isinstance(y, Iterable)
        if reduce == 'sum':
            return sum(torch.sum(x * yy) for yy in y)
        elif reduce is None:
            return [torch.sum(x * yy) for yy in y]
    elif not isinstance(x, torch.Tensor) and isinstance(y, torch.Tensor):
        assert isinstance(x, Iterable)
        if reduce == 'sum':
            return sum(torch.sum(xx * y) for xx in x)
        elif reduce is None:
            return [torch.sum(xx * y) for xx in x]
    # if both are lists of tensors, return the sum (reduction=sum)
    # or a list (reduction=None) of inner products
    else:
        assert isinstance(x, Iterable) and isinstance(y, Iterable)
        if isinstance(x, Sized) and isinstance(y, Sized):
            assert len(x) == len(y)
        if reduce == 'sum':
            return sum(torch.sum(xx * yy) for (xx, yy) in zip(x, y))
        elif reduce is None:
            return [torch.sum(xx * yy) for (xx, yy) in zip(x, y)]

def ipm(x, y, m, reduce='sum'):
    """
    vector-matrix-vector product x^T M y for tensors or lists of tensors
    """
    assert reduce == 'sum' or reduce is None
    # if all inputs are tensors, return vector-matrix-vector product
    if isinstance(x, torch.Tensor) and isinstance(y, torch.Tensor) and isinstance(m, torch.Tensor):
        return torch.einsum('bi,bij,bi->b', x, m, y)
    # if all inputs are lists of tensors, return the sum (reduction=sum)
    # or a list (reduction=None) of vector-matrix-vector product
    else:
        assert isinstance(x, Iterable)
        assert isinstance(y, Iterable)
        assert isinstance(m, Iterable)
        assert len(x) == len(y) == len(m)
        if reduce == 'sum':
            return sum(torch.sum(torch.einsum('bi,bij,bj->b', xx, mm, yy)) for (xx, mm, yy) in zip(x, m, y))
        elif reduce is None:
            return [torch.einsum('bi,bij,bj->b', xx, mm, yy) for (xx, mm, yy) in zip(x, m, y)]

def bmm(x, y):
    """
    batch matrix multiplication
    """
    return torch.einsum('bij,bjk->bik', x, y)

def op(x, y):
    """
    batch vector multiplication
    """
    return torch.einsum('bi,bj->bij', x, y)

def bmv(x, y):
    """
    batch matrix vector multiplication
    """
    return torch.einsum('bij,bj->bi', x, y)

def solve(A, b):
    """
    solution to linear equation Ax=b in batch
    """
    return torch.squeeze(torch.linalg.solve(A, torch.unsqueeze(b, -1)), -1)


def batch_jacobian(func, inputs, create_graph=False, strict=False):
    '''
    compute batch jacobians with autograd.functional.jacobian
    '''
    # auxiliary function with output as the output of the original function summed over batch axis
    def flat_func(_inputs):
        _outputs = func(_inputs)
        if isinstance(_outputs, torch.Tensor):
            return torch.sum(_outputs, 0)
        else:
            return tuple((torch.sum(_output, 0) for _output in _outputs))

    batch_size = inputs.shape[0]
    jacobians = autograd.functional.jacobian(flat_func, inputs, create_graph=create_graph, strict=strict)
    if isinstance(jacobians, torch.Tensor):
        jacobians = jacobians.transpose(0, 1)
    else:
        jacobians = [jac.transpose(0, 1) for jac in jacobians]
    return jacobians


def batch_gradient(outputs, inputs, grad_outputs=None, retain_graph=False, create_graph=False, only_inputs=True, allow_unused=True):
    '''
    compute batch gradients
    '''
    if isinstance(inputs, torch.Tensor):
        inputs = (inputs, )
        _tensor_input = True
    else:
        _tensor_input = False

    # make sure that requires_grad is True for all outputs
    if isinstance(outputs, torch.Tensor):
        if not outputs.requires_grad:
            if _tensor_input:
                return torch.zeros_like(inputs)
            else:
                return tuple(torch.zeros_like(x) for x in inputs)
    else:
        outputs = [output.requires_grad_(True) for output in outputs if not output.requires_grad]

    gradients = autograd.grad(
        outputs, inputs, grad_outputs,
        retain_graph=retain_graph,
        create_graph=create_graph,
        only_inputs=only_inputs,
        allow_unused=allow_unused
    )

    assert isinstance(gradients, tuple)

    gradients = tuple(torch.zeros_like(x) if grad is None else grad for (grad, x) in zip(gradients, inputs))

    if _tensor_input:
        return gradients[0]
    else:
        return gradients


def batch_gradient_safe(outputs, inputs, grad_outputs=None, retain_graph=False, create_graph=False, only_inputs=True, allow_unused=True):
    '''
    compute batch gradients with a graph that is always connected
    '''
    if isinstance(inputs, torch.Tensor):
        inputs = (inputs, )
        _tensor_input = True
    else:
        _tensor_input = False

    # make the graph always connected
    if isinstance(outputs, torch.Tensor):
        outputs = outputs + 0. * sum(torch.sum(x) for x in inputs)
    else:
        outputs = sum(outputs) + 0. * sum(torch.sum(x) for x in inputs)

    outputs.requires_grad_(True)

    gradients = autograd.grad(
        outputs, inputs, grad_outputs,
        retain_graph=retain_graph,
        create_graph=create_graph,
        only_inputs=only_inputs,
        allow_unused=allow_unused
    )

    gradients = tuple(torch.zeros_like(x) if grad is None else grad for (grad, x) in zip(gradients, inputs))

    if _tensor_input:
        return gradients[0]
    else:
        return gradients

def batch_hessian_two(func, x1, x2, output_numel):
    device=x1.device
    batch_size, input_numel = x1.size()

    x1_m = x1.repeat(1, output_numel).view(-1, input_numel).to(device)
    x1_m.requires_grad_(True)
    x2_m = x2.repeat(1, output_numel).view(-1, input_numel).to(device)
    x2_m.requires_grad_(True)
    y_m = func(x1_m, x2_m).to(device)
    mask1 = torch.eye(output_numel, device=device).repeat(batch_size, 1)
    dydx1 = torch.autograd.grad(y_m, x1_m, mask1, create_graph=True, allow_unused=True)[0]
        
    ddyddx1 = torch.zeros(batch_size, output_numel, input_numel, input_numel, device=device)
    ddydx1dx2 = torch.zeros(batch_size, output_numel, input_numel, input_numel, device=device)
    ddyddx2 = torch.zeros(batch_size, output_numel, input_numel, input_numel, device=device)
    ddydx2dx1 = torch.zeros(batch_size, output_numel, input_numel, input_numel, device=device)

    if dydx1 is not None:
        dydx1 = dydx1.reshape(batch_size, output_numel, input_numel)
        for i in range(input_numel):
            dydx1i = dydx1[:, :, i]
            mask = torch.eye(output_numel, input_numel, device=device).repeat(batch_size, 1)
            dydx1i_m = dydx1i.repeat(1, input_numel).view(-1, input_numel)
            ddyddx1i = torch.autograd.grad(dydx1i_m, x1_m, mask, create_graph=True, allow_unused=True)[0]
            if ddyddx1i is None:
                ddyddx1i = torch.zeros(batch_size, output_numel, input_numel, device=device)
            else:
                ddyddx1i = ddyddx1i.reshape(batch_size, output_numel, input_numel)
            ddyddx1[:, :, :, i] = ddyddx1i

            ddydx1dx2i = torch.autograd.grad(dydx1i_m, x2_m, mask, create_graph=True, allow_unused=True)[0]
            if ddydx1dx2i is None:
                ddydx1dx2i = torch.zeros(batch_size, output_numel, input_numel, device=device)
            else:
                ddydx1dx2i = ddydx1dx2i.reshape(batch_size, output_numel, input_numel)
            ddydx1dx2[:, :, :, i] = ddydx1dx2i
    else:
        dydx1 = torch.zeros(batch_size, output_numel, input_numel, device=device)

    dydx2 = torch.autograd.grad(y_m, x2_m, mask1, create_graph=True, allow_unused=True)[0]
    if dydx2 is not None:
        dydx2 = dydx2.reshape(batch_size, output_numel, input_numel)
        for i in range(input_numel):
            dydx2i = dydx2[:, :, i]
            mask = torch.eye(output_numel, input_numel, device=device).repeat(batch_size, 1)
            dydx2i_m = dydx2i.repeat(1, input_numel).view(-1, input_numel)
            ddyddx2i = torch.autograd.grad(dydx2i_m, x2_m, mask, create_graph=True, allow_unused=True)[0]
            if ddyddx2i is None:
                ddyddx2i = torch.zeros(batch_size, output_numel, input_numel, device=device)
            else:
                ddyddx2i = ddyddx2i.reshape(batch_size, output_numel, input_numel)
            ddyddx2[:, :, :, i] = ddyddx2i

            ddydx2dx1i = torch.autograd.grad(dydx2i_m, x1_m, mask, create_graph=True, allow_unused=True)[0]
            if ddydx2dx1i is None:
                ddydx2dx1i = torch.zeros(batch_size, output_numel, input_numel, device=device)
            else:
                ddydx2dx1i = ddydx2dx1i.reshape(batch_size, output_numel, input_numel)
            ddydx2dx1[:, :, :, i] = ddydx2dx1i
    else:
        dydx2 = torch.zeros(batch_size, output_numel, input_numel, device=device)

    return ddyddx1, ddydx1dx2, ddydx2dx1, ddyddx2, dydx1, dydx2

def initialize_weights(net, init_weight=0.01):
    for m in net.modules():
        if isinstance(m, nn.Conv2d):
            m.weight.data.normal_(0, init_weight)
            m.bias.data.zero_()
        elif isinstance(m, nn.ConvTranspose2d):
            m.weight.data.normal_(0, init_weight)
            m.bias.data.zero_()
        elif isinstance(m, nn.Linear):
            m.weight.data.normal_(0, init_weight)
            m.bias.data.zero_()

class MultiLayerPerceptron(nn.Module):
    def __init__(self, input_dim, output_dim, hidden_units, activation=nn.Tanh(), 
            init_weight=0.01, normalize=True, device=torch.device('cpu'), name='mlp'):
        super(MultiLayerPerceptron, self).__init__()
        layers = []
        in_dim = input_dim
        for h in hidden_units:
            layers.append(nn.Linear(in_dim, h, device=device))
            if normalize:
                # layers.append(nn.BatchNorm1d(h, device=device))
                layers.append(nn.LayerNorm(h, device=device))
            layers.append(activation)
            in_dim = h
        layers.append(nn.Linear(hidden_units[-1], output_dim, device=device))
        self.net = nn.Sequential(*layers)
        initialize_weights(self.net, init_weight)
        self.device = device
        self.name = name

    def __call__(self, x):
        x = self.net(x)
        return x

    def freeze(self):
        for p in self.net.parameters():
            p.requires_grad = False


