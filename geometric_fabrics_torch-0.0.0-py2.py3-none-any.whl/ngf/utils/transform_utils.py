import torch


# helper functions
# ----------------------------------------------------------
def rotation_rpy(rpy):
    """Returns a rotation matrix from roll pitch yaw. ZYX convention."""
    device = rpy.device
    dtype = rpy.dtype

    cr = torch.cos(rpy[0])
    sr = torch.sin(rpy[0])
    cp = torch.cos(rpy[1])
    sp = torch.sin(rpy[1])
    cy = torch.cos(rpy[2])
    sy = torch.sin(rpy[2])
    return torch.tensor([[cy*cp,  cy*sp*sr - sy*cr,  cy*sp*cr + sy*sr],
                         [sy*cp,  sy*sp*sr + cy*cr,  sy*sp*cr - cy*sr],
                         [  -sp,             cp*sr,             cp*cr]], dtype=dtype, device=rpy.device)


def T_rpy(displacement, rpy):
    """Homogeneous transformation matrix with roll pitch yaw."""
    device = displacement.device
    dtype = displacement.dtype

    T = torch.zeros(4, 4, dtype=dtype, device=device)
    T[:3, :3] = rotation_rpy(rpy)
    T[:3, 3] = displacement
    T[3, 3] = 1.0
    return T


def T_prismatic(xyz, rpy, axis, qi):
    batch_size = qi.shape[0]
    device = qi.device
    dtype = qi.dtype

    T = torch.zeros(batch_size, 4, 4, dtype=dtype, device=device)

    # Origin rotation from RPY ZYX convention
    cr = torch.cos(rpy[0])
    sr = torch.sin(rpy[0])
    cp = torch.cos(rpy[1])
    sp = torch.sin(rpy[1])
    cy = torch.cos(rpy[2])
    sy = torch.sin(rpy[2])
    r00 = cy*cp
    r01 = cy*sp*sr - sy*cr
    r02 = cy*sp*cr + sy*sr
    r10 = sy*cp
    r11 = sy*sp*sr + cy*cr
    r12 = sy*sp*cr - cy*sr
    r20 = -sp
    r21 = cp*sr
    r22 = cp*cr
    p0 = r00*axis[0]*qi + r01*axis[1]*qi + r02*axis[2]*qi
    p1 = r10*axis[0]*qi + r11*axis[1]*qi + r12*axis[2]*qi
    p2 = r20*axis[0]*qi + r21*axis[1]*qi + r22*axis[2]*qi

    # Homogeneous transformation matrix
    T[:, 0, 0] = r00
    T[:, 0, 1] = r01
    T[:, 0, 2] = r02
    T[:, 1, 0] = r10
    T[:, 1, 1] = r11
    T[:, 1, 2] = r12
    T[:, 2, 0] = r20
    T[:, 2, 1] = r21
    T[:, 2, 2] = r22
    T[:, 0, 3] = xyz[0] + p0
    T[:, 1, 3] = xyz[1] + p1
    T[:, 2, 3] = xyz[2] + p2
    T[:, 3, 3] = 1.0
    return T


def T_revolute(xyz, rpy, axis, qi):
    batch_size = qi.shape[0]
    device = qi.device
    dtype = qi.dtype

    T = torch.zeros(batch_size, 4, 4, dtype=dtype, device=device)

    # Origin rotation from RPY ZYX convention
    cr = torch.cos(rpy[0])
    sr = torch.sin(rpy[0])
    cp = torch.cos(rpy[1])
    sp = torch.sin(rpy[1])
    cy = torch.cos(rpy[2])
    sy = torch.sin(rpy[2])
    r00 = cy*cp
    r01 = cy*sp*sr - sy*cr
    r02 = cy*sp*cr + sy*sr
    r10 = sy*cp
    r11 = sy*sp*sr + cy*cr
    r12 = sy*sp*cr - cy*sr
    r20 = -sp
    r21 = cp*sr
    r22 = cp*cr

    # joint rotation from skew sym axis angle
    cqi = torch.cos(qi)
    sqi = torch.sin(qi)
    s00 = (1 - cqi)*axis[0]*axis[0] + cqi
    s11 = (1 - cqi)*axis[1]*axis[1] + cqi
    s22 = (1 - cqi)*axis[2]*axis[2] + cqi
    s01 = (1 - cqi)*axis[0]*axis[1] - axis[2]*sqi
    s10 = (1 - cqi)*axis[0]*axis[1] + axis[2]*sqi
    s12 = (1 - cqi)*axis[1]*axis[2] - axis[0]*sqi
    s21 = (1 - cqi)*axis[1]*axis[2] + axis[0]*sqi
    s20 = (1 - cqi)*axis[0]*axis[2] - axis[1]*sqi
    s02 = (1 - cqi)*axis[0]*axis[2] + axis[1]*sqi

    # Homogeneous transformation matrix
    T[:, 0, 0] = r00*s00 + r01*s10 + r02*s20
    T[:, 1, 0] = r10*s00 + r11*s10 + r12*s20
    T[:, 2, 0] = r20*s00 + r21*s10 + r22*s20

    T[:, 0, 1] = r00*s01 + r01*s11 + r02*s21
    T[:, 1, 1] = r10*s01 + r11*s11 + r12*s21
    T[:, 2, 1] = r20*s01 + r21*s11 + r22*s21

    T[:, 0, 2] = r00*s02 + r01*s12 + r02*s22
    T[:, 1, 2] = r10*s02 + r11*s12 + r12*s22
    T[:, 2, 2] = r20*s02 + r21*s12 + r22*s22

    T[:, 0, 3] = xyz[0]
    T[:, 1, 3] = xyz[1]
    T[:, 2, 3] = xyz[2]
    T[:, 3, 3] = 1.0
    return T