import numpy as np
import pickle
import torch
import os
from ngf.utils.dataset_utils import CspaceDataset, DexlearnDataset, \
    DexlearnDiscreteDataset, AllegroDataset, AllegroDatasetSim2Real, ShadowDataset, KoopmannDataset

def load_synthesized(cspace_dim, sequence=False, device=torch.device('cpu'), dtype=torch.float32):
    t = torch.arange(0, 1, 0.01, dtype=dtype).reshape(-1, 1)
    dt = torch.full(t.shape, 0.01, dtype=dtype)
    q = torch.cat([torch.sin(t)]*cspace_dim, axis=1)
    qd = torch.cat([torch.cos(t)]*cspace_dim, axis=1)
    qdd = torch.cat([-torch.sin(t)]*cspace_dim, axis=1)

    start = torch.zeros_like(q)
    goal = torch.ones_like(q)

    trajectories = torch.cat([q, qd, qdd, start, goal, t, dt], axis=1)
    if sequence:
        trajectories = torch.cat(200*[trajectories.unsqueeze(0)]).to(device)
    else:
        trajectories = torch.cat(200*[trajectories]).to(device)

    return trajectories

def load_synthesized_data(trajectories, cspace_dim, goal_dim = 7, begin=None, end=None):
    if len(trajectories.shape) == 2:
        q = trajectories[:, :cspace_dim]
        qd = trajectories[:, cspace_dim:2*cspace_dim]
        qdd = trajectories[:, 2*cspace_dim:3*cspace_dim]
        start = trajectories[:, 3*cspace_dim:3*cspace_dim+goal_dim]
        goal = trajectories[:, 3*cspace_dim+goal_dim:-2]
        t = trajectories[:, -2:-1]
        dt = trajectories[:, -1:]
    else:
        q = trajectories[:, :, :cspace_dim]
        qd = trajectories[:, :, cspace_dim:2*cspace_dim]
        qdd = trajectories[:, :, 2*cspace_dim:3*cspace_dim]
        start = trajectories[:, :, 3*cspace_dim:3*cspace_dim+goal_dim]
        goal = trajectories[:, :, 3*cspace_dim+goal_dim:-2]
        t = trajectories[:, :, -2:-1]
        dt = trajectories[:, :, -1:]

    if begin is None and end is None:
        train_dataset = {
            'dt': dt,
            't': t,
            'q': q,
            'qd': qd,
            'qdd': qdd,
            'start': start,
            'goal': goal,
        }
    else:
        train_dataset = {
            'dt': dt[begin:end],
            't': t[begin:end],
            'q': q[begin:end],
            'qd': qd[begin:end],
            'qdd': qdd[begin:end],
            'start': start[begin:end],
            'goal': goal[begin:end],
        }

    return train_dataset

def load_synthesized_dataset(trajectories, cspace_dim, goal_dim = 7):
    if len(trajectories.shape) == 2:
        q = trajectories[:, :cspace_dim]
        qd = trajectories[:, cspace_dim:2*cspace_dim]
        qdd = trajectories[:, 2*cspace_dim:3*cspace_dim]
        start = trajectories[:, 3*cspace_dim:3*cspace_dim+goal_dim]
        goal = trajectories[:, 3*cspace_dim+goal_dim:-2]
        t = trajectories[:, -2:-1]
        dt = trajectories[:, -1:]
    else:
        q = trajectories[:, :, :cspace_dim]
        qd = trajectories[:, :, cspace_dim:2*cspace_dim]
        qdd = trajectories[:, :, 2*cspace_dim:3*cspace_dim]
        start = trajectories[:, :, 3*cspace_dim:3*cspace_dim+goal_dim]
        goal = trajectories[:, :, 3*cspace_dim+goal_dim:-2]
        t = trajectories[:, :, -2:-1]
        dt = trajectories[:, :, -1:]

    key_list = ['dt', 't', 'q', 'qd', 'qdd', 'start', 'goal']

    return CspaceDataset(dt=dt, t=t, q=q, qd=qd, qdd=qdd, start=start, goal=goal), key_list

def load_allegro_dataset(data_dir, data_filename, sub_sampling=False, sub_rate=1, both_pcds=False, noisy_meas=False,
        train_size=None, validation_size=None, device=torch.device('cpu'), dtype=torch.float32):
    data_path = os.path.join(data_dir, data_filename)
    if (data_filename in os.listdir(data_dir)):
        data_file = open(data_path, "rb")
        data_dict = pickle.load(data_file)
    else:
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        print("!!!!!!!! data file does not exist !!!!!!!!")
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    data_file.close()

    metadata = data_dict['metadata']
    trajectories = data_dict['trajectories']

    num_envs = metadata['num_envs']
    num_episodes = metadata['current_episode_shape']
    episode_length = metadata['episode_length']

    q_measured = trajectories["joint_positions"] 
    qd_measured = trajectories["joint_velocities"]
    actions = trajectories["actions"] # commanded joint positions #TODO: temp use for the time being
    if "point_clouds" in trajectories.keys():
        point_clouds = trajectories["point_clouds"]
        if 'point_clouds_noisy' in trajectories.keys():
            point_clouds_noisy = trajectories["point_clouds_noisy"]
        else:
            point_clouds_noisy = trajectories['point_clouds']
    else:
        point_clouds = np.zeros_like(actions)
        point_clouds_noisy = point_clouds
    cube_state = trajectories["cube_state"]
    goal_state = trajectories["goal_state"]
    masks = trajectories["masks"]
    reset_buf = trajectories["reset_buf"]

    actions = actions.reshape(num_envs*num_episodes, episode_length, -1)
    q_measured = q_measured.reshape(num_envs*num_episodes, episode_length, -1)
    qd_measured = qd_measured.reshape(num_envs*num_episodes, episode_length, -1)
    point_clouds = point_clouds.reshape(num_envs*num_episodes, episode_length, -1)
    point_clouds_noisy = point_clouds_noisy.reshape(num_envs*num_episodes, episode_length, -1)
    cube_state = cube_state.reshape(num_envs*num_episodes, episode_length, -1)
    goal_state = goal_state.reshape(num_envs*num_episodes, episode_length, -1)
    masks = masks.reshape(num_envs*num_episodes, episode_length, -1)
    reset_buf = reset_buf.reshape(num_envs*num_episodes, episode_length, -1)

    if sub_sampling:
        actions = actions[:, ::sub_rate]
        q_measured = q_measured[:, ::sub_rate]
        qd_measured = qd_measured[:, ::sub_rate]
        point_clouds = point_clouds[:, ::sub_rate]
        point_clouds_noisy = point_clouds_noisy[:, ::sub_rate]
        cube_state = cube_state[:, ::sub_rate]
        goal_state = goal_state[:, ::sub_rate]
        masks = masks[:, ::sub_rate]
        reset_buf = reset_buf[:, ::sub_rate]

    #TODO: temp use for the time being
    if noisy_meas:
        q_mean = q_measured.copy()
        q_measured = np.random.normal(q_mean, 0.1, q_mean.shape)

    q_measured = torch.tensor(q_measured, dtype=dtype, device=device)
    qd_measured = torch.tensor(qd_measured, dtype=dtype, device=device)
    actions = torch.tensor(actions, dtype=dtype, device=device)
    point_clouds = torch.tensor(point_clouds, dtype=dtype, device=device)
    point_clouds_noisy = torch.tensor(point_clouds_noisy, dtype=dtype, device=device)
    cube_state = torch.tensor(cube_state, dtype=dtype, device=device)
    goal_state = torch.tensor(goal_state, dtype=dtype, device=device)
    masks = torch.tensor(masks, dtype=dtype, device=device)
    reset_buf = torch.tensor(reset_buf, dtype=dtype, device=device)

    q_prev = torch.cat((torch.zeros_like(actions[:, 0:2]), actions[:, :-2]), dim=1)
    q_cur = torch.cat((torch.zeros_like(actions[:, 0:1]), actions[:, :-1]), dim=1)

    if train_size is None:
        train_size = num_envs * num_episodes
    else:
        train_size = min(train_size, num_envs * num_episodes)
    if validation_size is None:
        validation_size = num_envs * num_episodes - train_size
    else:
        validation_size = min(validation_size, num_envs * num_episodes - train_size)
    print('train size', train_size, 'validation size', validation_size)

    if both_pcds:
        key_list = ['actions', 'q_prev', 'q_cur', 'q_measured', 'qd_measured', 'point_clouds', 
            'point_clouds_noisy', 'cube_pose', 'goal_pose', 'masks']
        
        if validation_size == 0:
            train_dataset = AllegroDatasetSim2Real(actions=actions, q_prev=q_prev, q_cur=q_cur, 
                q_measured=q_measured, qd_measured=qd_measured, point_clouds=point_clouds, 
                point_clouds_noisy=point_clouds_noisy, cube_pose=cube_state[..., :7], goal_pose=goal_state[..., :7], masks=masks)
            validation_dataset = None
        else:
            train_dataset = AllegroDatasetSim2Real(actions=actions[:train_size], q_prev=q_prev[:train_size], q_cur=q_cur[:train_size], 
                q_measured=q_measured[:train_size], qd_measured=qd_measured[:train_size], point_clouds=point_clouds[:train_size],
                point_clouds_noisy=point_clouds_noisy[:train_size], cube_pose=cube_state[:train_size, :, :7], 
                goal_pose=goal_state[:train_size, :, :7], masks=masks[:train_size])
            validation_dataset = AllegroDatasetSim2Real(actions=actions[train_size:], q_prev=q_prev[train_size:], q_cur=q_cur[train_size:], 
                q_measured=q_measured[train_size:], qd_measured=qd_measured[train_size:], point_clouds=point_clouds[train_size:],
                point_clouds_noisy=point_clouds_noisy[train_size:], cube_pose=cube_state[train_size:, :, :7], 
                goal_pose=goal_state[train_size:, :, :7], masks=masks[train_size:])
    else:
        key_list = ['actions', 'q_prev', 'q_cur', 'q_measured', 'qd_measured', 'point_clouds', 
            'cube_pose', 'goal_pose', 'masks', 'reset_buf']
        
        if validation_size == 0:
            train_dataset = AllegroDataset(actions=actions, q_prev=q_prev, q_cur=q_cur, 
                q_measured=q_measured, qd_measured=qd_measured, point_clouds=point_clouds, 
                cube_pose=cube_state[..., :7], goal_pose=goal_state[..., :7], masks=masks, reset_buf=reset_buf)
            validation_dataset = None
        else:
            train_dataset = AllegroDataset(actions=actions[:train_size], q_prev=q_prev[:train_size], q_cur=q_cur[:train_size], 
                q_measured=q_measured[:train_size], qd_measured=qd_measured[:train_size], point_clouds=point_clouds[:train_size],
                cube_pose=cube_state[:train_size, :, :7], goal_pose=goal_state[:train_size, :, :7], masks=masks[:train_size], 
                reset_buf=reset_buf[:train_size])
            validation_dataset = AllegroDataset(actions=actions[train_size:], q_prev=q_prev[train_size:], q_cur=q_cur[train_size:], 
                q_measured=q_measured[train_size:], qd_measured=qd_measured[train_size:], point_clouds=point_clouds[train_size:],
                cube_pose=cube_state[train_size:, :, :7], goal_pose=goal_state[train_size:, :, :7], masks=masks[train_size:],
                reset_buf=reset_buf[train_size:])

    return train_dataset, validation_dataset, key_list

def load_shadow_dataset(data_dir, data_filename, sub_sampling=False, sub_rate=1,
        train_size=None, validation_size=None, device=torch.device('cpu'), dtype=torch.float32):
    data_path = os.path.join(data_dir, data_filename)
    if (data_filename in os.listdir(data_dir)):
        data_file = open(data_path, "rb")
        data_dict = pickle.load(data_file)
    else:
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        print("!!!!!!!! data file does not exist !!!!!!!!")
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    data_file.close()

    actions = data_dict["actions"] 
    q_measured = data_dict["q_measured"] 
    qd_measured = data_dict["qd_measured"]
    cube_pose = data_dict["cube_pose"]
    goal_pose = data_dict["goal_pose"]
    object_points = data_dict["object_points"]
    object_normals = data_dict["object_normals"]
    target_points = data_dict["target_points"]
    target_normals = data_dict["target_normals"]

    num_episodes = actions.shape[0]

    if sub_sampling:
        actions = actions[:, ::sub_rate]
        q_measured = q_measured[:, ::sub_rate]
        qd_measured = qd_measured[:, ::sub_rate]
        cube_pose = cube_pose[:, ::sub_rate]
        goal_pose = goal_pose[:, ::sub_rate]
        object_points = object_points[:, ::sub_rate]
        object_normals = object_normals[:, ::sub_rate]
        target_points = target_points[:, ::sub_rate]
        target_normals = target_normals[:, ::sub_rate]

    actions = torch.tensor(actions, dtype=dtype, device=device)
    q_measured = torch.tensor(q_measured, dtype=dtype, device=device)
    qd_measured = torch.tensor(qd_measured, dtype=dtype, device=device)
    cube_pose = torch.tensor(cube_pose, dtype=dtype, device=device)
    goal_pose = torch.tensor(goal_pose, dtype=dtype, device=device)
    object_points = torch.tensor(object_points, dtype=dtype, device=device)
    object_normals = torch.tensor(object_normals, dtype=dtype, device=device)
    target_points = torch.tensor(target_points, dtype=dtype, device=device)
    target_normals = torch.tensor(target_normals, dtype=dtype, device=device)

    q_cur = torch.cat((torch.zeros_like(actions[:, 0:1]), actions[:, :-1]), dim=1)

    if train_size is None:
        train_size = num_episodes
    else:
        train_size = min(train_size, num_episodes)
    if validation_size is None:
        validation_size = num_episodes - train_size
    else:
        validation_size = min(validation_size, num_episodes - train_size)
    print('train size', train_size, 'validation size', validation_size)

    key_list = ['actions', 'q_cur', 'q_measured', 'qd_measured', 'cube_pose', 'goal_pose', \
        'object_points', 'object_normals', 'target_points', 'target_normals']
    
    if validation_size == 0:
        train_dataset = ShadowDataset(actions=actions, q_cur=q_cur, 
            q_measured=q_measured, qd_measured=qd_measured,
            cube_pose=cube_pose, goal_pose=goal_pose,
            object_points=object_points, object_normals=object_normals,
            target_points=target_points, target_normals=target_normals)
        validation_dataset = None
    else:
        train_dataset = ShadowDataset(actions=actions[:train_size], q_cur=q_cur[:train_size], 
            q_measured=q_measured[:train_size], qd_measured=qd_measured[:train_size],
            cube_pose=cube_pose[:train_size], goal_pose=goal_pose[:train_size],
            object_points=object_points[:train_size], object_normals=object_normals[:train_size],
            target_points=target_points[:train_size], target_normals=target_normals[:train_size])
        validation_dataset = ShadowDataset(actions=actions[train_size:], q_cur=q_cur[train_size:], 
            q_measured=q_measured[train_size:], qd_measured=qd_measured[train_size:], 
            cube_pose=cube_pose[train_size:], goal_pose=goal_pose[train_size:],
            object_points=object_points[train_size:], object_normals=object_normals[train_size:],
            target_points=target_points[train_size:], target_normals=target_normals[train_size:])

    return train_dataset, validation_dataset, key_list

def load_dexlearn(data_dir, data_filename, cspace_dim, eef_task_map, sub_sampling=False, sub_rate=1, 
        sequence=False, window_size=None, train_size=None, validation_size=None, dtype=torch.float32):

    data_path = os.path.join(data_dir, data_filename)
    if (data_filename in os.listdir(data_dir)):
        data_file = open(data_path, "rb")
        data_dict = pickle.load(data_file)
    else:
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        print("!!!!!!!! data file does not exist !!!!!!!!")
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    data_file.close()

    t = torch.from_numpy(data_dict["t"]).to(dtype)
    q = torch.from_numpy(data_dict["q"][:, :cspace_dim]).to(dtype)
    qd = torch.from_numpy(data_dict["qd"][:, :cspace_dim]).to(dtype)
    qdd = torch.from_numpy(data_dict["qdd"][:, :cspace_dim]).to(dtype)
    obj_poses = torch.from_numpy(data_dict["obj_poses"]).to(dtype) # quat (x, y, z, w) + trans (x, y, z)

    if 'obj_ids' in data_dict.keys():
        obj_ids = torch.from_numpy(data_dict["obj_ids"]).to(dtype)
        obj_ids_list = obj_ids.reshape(-1).tolist()
        obj_ids = torch.zeros((len(obj_ids_list), len(set(obj_ids_list))), dtype=dtype)
        for i, id in enumerate(obj_ids_list):
            obj_ids[i, int(id)-1] = 1
    else:
        obj_ids = torch.zeros_like(t)

    wspace_dim = 3
    data_size = t.shape[0]
    start_idx = np.where(t==0)[0]
    end_idx = np.concatenate([start_idx[1:]-1, np.array([data_size-1])])

    if sub_sampling:
        # subsampling data
        t_sub = []
        q_sub = []
        qd_sub = []
        qdd_sub = []
        obj_poses_sub = []
        obj_ids_sub = []

        for idx_s, idx_e in zip(start_idx, end_idx):
            idxes = np.arange(idx_s, idx_e, sub_rate)
            if idxes[-1] != idx_e and (idx_e-idx_s+1)%sub_rate !=0:
                idxes = np.concatenate((idxes, idx_e.reshape(-1)))
            t_sub.append(t[idxes])
            q_sub.append(q[idxes])
            qd_sub.append(qd[idxes])
            qdd_sub.append(qdd[idxes])
            obj_poses_sub.append(obj_poses[idxes])
            obj_ids_sub.append(obj_ids[idxes])

        t = torch.cat(t_sub)
        q = torch.cat(q_sub)
        qd = torch.cat(qd_sub)
        qdd = torch.cat(qdd_sub)
        obj_poses = torch.cat(obj_poses_sub)
        obj_ids = torch.cat(obj_ids_sub)

        data_size = t.shape[0]
        start_idx = np.where(t==0)[0]
        end_idx = np.concatenate([start_idx[1:]-1, np.array([data_size-1])])

    goal = torch.zeros((data_size, wspace_dim))
    init_pose = torch.zeros_like(obj_poses)       
    eef_pos = eef_task_map(q)

    max_len = 0
    dt = torch.zeros_like(t)
    delta_q = torch.zeros_like(q)
    q_prev = torch.zeros_like(q)
    q_next = torch.zeros_like(q)
    for idx_s, idx_e in zip(start_idx, end_idx):
        max_len = max(max_len, idx_e - idx_s + 1)
        goal[idx_s:idx_e+1] = eef_pos[idx_e]
        init_pose[idx_s:idx_e+1] = obj_poses[idx_s]
        dt[idx_s:idx_e] = t[idx_s+1:idx_e+1] - t[idx_s:idx_e]
        delta_q[idx_s:idx_e] =  q[idx_s+1:idx_e+1] - q[idx_s:idx_e] 
        delta_q[idx_e] =  delta_q[idx_e-1]
        q_prev[idx_s+1:idx_e+1] = q[idx_s:idx_e]
        q_prev[idx_s] = q[idx_s] - delta_q[idx_s]
        q_next[idx_s:idx_e] = q[idx_s+1:idx_e+1]
        q_next[idx_e] = q[idx_e] + delta_q[idx_e]
  
    trajectories = torch.cat((q, qd, qdd, delta_q, q_prev, q_next, goal, init_pose, obj_ids, t, dt), axis=1)

    if train_size is None:
        train_size = len(start_idx)
    else:
        train_size = min(train_size, len(start_idx))
    if validation_size is None:
        validation_size = len(start_idx) - train_size
    else:
        validation_size = min(validation_size, len(start_idx) - train_size)
    print('train size', train_size, 'validation size', validation_size)
    
    if sequence:
        if window_size is None:
            window_size = max_len
        D = trajectories.shape[1]
        mini_traj = []
        for idx_s, idx_e in zip(start_idx, end_idx):
            traj = trajectories[idx_s:idx_e+1]
            traj_len = idx_e - idx_s + 1
            if traj_len < window_size:
                pad_size = window_size - traj_len
                traj_tail = torch.from_numpy(np.full((pad_size, D), traj[-1]))
                traj_tail[:, -1] = 0
                traj = torch.cat((traj, traj_tail))
                traj_len = window_size

            j = 0
            while j < traj_len-1:
                if j + window_size < traj_len:
                    mini_traj.append(traj[j:j+window_size].reshape(1, window_size, D)) 
                else:
                    mini_traj.append(traj[traj_len - window_size:].reshape(1, window_size, D)) 
                if window_size > 1:
                    j = j + window_size - 1
                else:
                    j = j + window_size

        mini_traj = torch.cat(mini_traj, axis=0)
        print('mini_traj shape:', mini_traj.shape)

        num_traj = len(start_idx)
        num_mini_traj = mini_traj.shape[0]
        num_train = int((train_size/num_traj) * num_mini_traj)
        num_validation = int((validation_size/num_traj) * num_mini_traj)
        
        train_dataset = mini_traj[:num_train]
        validation_dataset = mini_traj[-num_validation:] 
    else:
        train_index = end_idx[train_size-1]+1
        validation_index = end_idx[-validation_size-1]+1

        train_dataset = trajectories[:train_index]
        validation_dataset = trajectories[validation_index:]
    
    if validation_size == 0:
        validation_dataset = None

    return train_dataset, validation_dataset
 
def load_dexlearn_data(trajectories, cspace_dim, goal_dim=3, pose_dim=4, 
        begin=None, end=None, device=torch.device('cpu'), dtype=torch.float32):
    trajectories = trajectories.to(dtype).to(device)
    if len(trajectories.shape) == 2:
        q = trajectories[:, :cspace_dim]
        qd = trajectories[:, cspace_dim:2*cspace_dim]
        qdd = trajectories[:, 2*cspace_dim:3*cspace_dim]
        delta_q = trajectories[:, 3*cspace_dim:4*cspace_dim]
        q_prev = trajectories[:, 4*cspace_dim:5*cspace_dim]
        q_next = trajectories[:, 5*cspace_dim:6*cspace_dim]
        goal = trajectories[:, 6*cspace_dim:6*cspace_dim+goal_dim]
        init_pose = trajectories[:, 6*cspace_dim+goal_dim:-2]
        t = trajectories[:, -2:-1]
        dt = trajectories[:, -1:]
    else:
        q = trajectories[:, :, :cspace_dim]
        qd = trajectories[:, :, cspace_dim:2*cspace_dim]
        qdd = trajectories[:, :, 2*cspace_dim:3*cspace_dim]
        delta_q = trajectories[:, :, 3*cspace_dim:4*cspace_dim]
        q_prev = trajectories[:, :, 4*cspace_dim:5*cspace_dim]
        q_next = trajectories[:, :, 5*cspace_dim:6*cspace_dim]
        goal = trajectories[:, :, 6*cspace_dim:6*cspace_dim+goal_dim]
        init_pose = trajectories[:, :, 6*cspace_dim+goal_dim:-2]
        t = trajectories[:, :, -2:-1]
        dt = trajectories[:, :, -1:]

    if begin is None and end is None:
        train_dataset = {
            'dt': dt,
            't': t,
            'q': q,
            'qd': qd,
            'qdd': qdd,
            'delta_q': delta_q,
            'q_prev': q_prev,
            'q_next': q_next,
            'goal': goal,
            'init_pose': init_pose,
        }
    else:
        train_dataset = {
            'dt': dt[begin:end],
            't': t[begin:end],
            'q': q[begin:end],
            'qd': qd[begin:end],
            'qdd': qdd[begin:end],
            'delta_q': delta_q[begin:end],
            'q_prev': q_prev[begin:end],
            'q_next': q_next[begin:end],
            'goal': goal[begin:end],
            'init_pose': init_pose[begin:end],
        }

    return train_dataset

def load_dexlearn_dataset(trajectories, cspace_dim, goal_dim=3, pose_dim=4, 
        discrete=False, device=torch.device('cpu'), dtype=torch.float32):
    trajectories = trajectories.to(dtype).to(device)
    if len(trajectories.shape) == 2:
        q = trajectories[:, :cspace_dim]
        qd = trajectories[:, cspace_dim:2*cspace_dim]
        qdd = trajectories[:, 2*cspace_dim:3*cspace_dim]
        delta_q = trajectories[:, 3*cspace_dim:4*cspace_dim]
        q_prev = trajectories[:, 4*cspace_dim:5*cspace_dim]
        q_next = trajectories[:, 5*cspace_dim:6*cspace_dim]
        goal = trajectories[:, 6*cspace_dim:6*cspace_dim+goal_dim]
        init_pose = trajectories[:, 6*cspace_dim+goal_dim:6*cspace_dim+goal_dim+pose_dim]
        obj_ids = trajectories[:, 6*cspace_dim+goal_dim+pose_dim:-2]
        t = trajectories[:, -2:-1]
        dt = trajectories[:, -1:]
    else:
        q = trajectories[:, :, :cspace_dim]
        qd = trajectories[:, :, cspace_dim:2*cspace_dim]
        qdd = trajectories[:, :, 2*cspace_dim:3*cspace_dim]
        delta_q = trajectories[:, :, 3*cspace_dim:4*cspace_dim]
        q_prev = trajectories[:, :, 4*cspace_dim:5*cspace_dim]
        q_next = trajectories[:, :, 5*cspace_dim:6*cspace_dim]
        goal = trajectories[:, :, 6*cspace_dim:6*cspace_dim+goal_dim]
        init_pose = trajectories[:, :, 6*cspace_dim+goal_dim:6*cspace_dim+goal_dim+pose_dim]
        obj_ids = trajectories[:, :, 6*cspace_dim+goal_dim+pose_dim:-2]
        t = trajectories[:, :, -2:-1]
        dt = trajectories[:, :, -1:]

    if discrete:
        key_list = ['dt', 't', 'q', 'delta_q', 'q_prev', 'q_next', 'goal', 'init_pose', 'obj_ids']
        return DexlearnDiscreteDataset(dt=dt, t=t, q=q, delta_q=delta_q, q_next=q_next, 
                    goal=goal, init_pose=init_pose, obj_ids=obj_ids), key_list
    else:
        key_list = ['dt', 't', 'q', 'qd', 'qdd', 'goal', 'init_pose', 'obj_ids']
        return DexlearnDataset(dt=dt, t=t, q=q, qd=qd, qdd=qdd, goal=goal, init_pose=init_pose, obj_ids=obj_ids), key_list

def load_koopmann_dataset(data_dir, data_filename, train_size=None, validation_size=None, 
        sub_sampling=False, sub_rate=1, device=torch.device('cpu'), dtype=torch.float32):
    data_path = os.path.join(data_dir, data_filename)
    if (data_filename in os.listdir(data_dir)):
        data_file = open(data_path, "rb")
        data_dict = pickle.load(data_file)
    else:
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        print("!!!!!!!! data file does not exist !!!!!!!!")
        print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
    data_file.close()

    num_traj = data_dict["num_traj"]
    q = np.array([data_dict["hand_joint"]]).squeeze()
    if "hand_velocity" in data_dict.keys():
        qd = np.array([data_dict["hand_velocity"]]).squeeze()
    else:
        qd = np.zeros_like(q)
    obj_states = np.array([data_dict["object_states"]]).squeeze()

    if sub_sampling:
        q = q[:, ::sub_rate]
        qd = qd[:, ::sub_rate]
        obj_states = obj_states[:, ::sub_rate]

    q = torch.tensor(q, dtype=dtype, device=device)
    qd = torch.tensor(qd, dtype=dtype, device=device)
    obj_states = torch.tensor(obj_states, dtype=dtype, device=device)

    if train_size is None:
        train_size = num_traj
    else:
        train_size = min(train_size, num_traj)
    if validation_size is None:
        validation_size = num_traj - train_size
    else:
        validation_size = min(validation_size, num_traj - train_size)
    print('train size', train_size, 'validation size', validation_size)

    key_list = ['q', 'qd', 'obj_states']
    
    if validation_size == 0:
        train_dataset = KoopmannDataset(q=q, qd=qd, obj_states=obj_states)
        validation_dataset = None
    else:
        train_dataset = KoopmannDataset(q=q[:train_size], qd=qd[:train_size], obj_states=obj_states[:train_size])
        validation_dataset = KoopmannDataset(q=q[train_size:], qd=qd[train_size:], obj_states=obj_states[train_size:])

    return train_dataset, validation_dataset, key_list