import torch
from torch import nn

class BarrierMetric(nn.Module):
    '''
    Barrier Metric on 1D task space
    '''
    def __init__(self, epsilon=0.2, slope_order=1, scale=1.):
        super(BarrierMetric, self).__init__()
        self.epsilon = epsilon
        self.slope_order = slope_order
        self.scale = scale

    def __call__(self, x):
        return (self.barrier_scalar(self.scale * x) + self.epsilon)

    def barrier_scalar(self, x):
        w = 1. / torch.pow(x, self.slope_order)
        return w

class Directional1DToggleMetric(nn.Module):
    '''
    Operates on 1D space, x. If x < 0 (for decresing vel, for instance), then switch is high.
    otherwise, switch is low
    '''
    def __int__(self, axis=None, flip_sign=False):
        super(Directional1DToggleMetric, self).__init__()
        self.axis = axis
        self.flip_sign = flip_sign


    def __call__(self, xd):
        if self.axis is None:
            G = self.toggle(xd)
        else:
            G = self.toggle(xd[:, self.axis])
        return G

    def toggle(self, scalar):
        if self.flip_sign:
            scalar *= -1
        if scalar >= 0:
            switch = 0.0
        else:
            switch = 1.0

        return switch

class IdentityMetric(nn.Module):
    def __init__(self, scaling=1.):
        super(IdentityMetric, self).__init__()
        self.scaling = scaling

    def __call__(self, q, qd=None):
        n, d = q.size()
        metric = torch.eye(d, device=q.device).repeat(n, 1, 1) * self.scaling
        return metric


class FloorLiftMetric(nn.Module):
    '''
    Metric used with floor lift geometry
    '''
    def __init__(self, proportional_gain=1.0, length_scale=1.0, floor_height=0.0,
            epsilon=1e-16):
        super(FloorLiftMetric, self).__init__()
        self.proportional_gain = proportional_gain
        self.length_scale = length_scale
        self.floor_height = floor_height
        self.epsilon = epsilon

    def __call__(self, x, xd=None):
        n, d = x.size()
        alpha = self.proportional_gain * torch.exp(-(x[:, -1] - self.floor_height)/self.length_scale).reshape(-1, 1)
        G = torch.eye(d, device=x.device).repeat(n, 1, 1)
        G = torch.einsum('bij, bk->bij', G, alpha+self.epsilon)
        return G

class GoalAttractorMetric(nn.Module):
    '''
    Metric used with floor lift geometry
    '''
    def __init__(self, proportional_gain=1.0, length_scale=1.0, epsilon=1e-16):
        super(GoalAttractorMetric, self).__init__()
        self.proportional_gain = proportional_gain
        self.length_scale = length_scale
        self.epsilon = epsilon

    def __call__(self, x, xd=None):
        n, d = x.size()
        alpha = self.proportional_gain * torch.exp(-0.5*(x[:, 0]/self.length_scale) ** 2).reshape(-1, 1)
        G = torch.eye(d, device=x.device).repeat(n, 1, 1) 
        G = torch.einsum('bij, bk->bij', G, alpha+self.epsilon)
        return G