import torch
from torch import nn
from torch.nn import functional as F

class ReluBarrierPotential(nn.Module):
    '''
    A mixture of barrier and flipped ReLu to get linear escalation before power growth
    '''
    def __init__(self, barrier_gain=1e-1, relu_gain=5e-2, relu_rate=20., relu_offset=5.):
        super(ReluBarrierPotential, self).__init__()

        self.barrier_gain = barrier_gain
        self.relu_gain = relu_gain
        self.relu_rate = relu_rate
        self.relu_offset = relu_offset

    def __call__(self, x):
        barrier = self.barrier_scalar(x)
        relu = self.relu(x)
        phi = self.barrier_gain * barrier + self.relu_gain * relu
        return phi

    def grad(self, x):
        grad_phi = self.barrier_gain * self.del_barrier_scalar(x) + self.relu_gain * self.del_relu(x)

        return grad_phi

    def barrier_scalar(self, x):
        w = 1. / x

        return w

    def del_barrier_scalar(self, x):
        del_w = -1. / x ** 2

        return del_w

    def relu(self, x):
        w = torch.log(1. + torch.exp(-self.relu_rate * (x - self.relu_offset)))
        return w

    def del_relu(self, x):
        exp_term = torch.exp(-self.relu_rate * (x - self.relu_offset))
        del_w = self.relu_rate ** 2 * (x - self.relu_offset) * exp_term / ( 1 + exp_term)

        return del_w


class LogCoshPotential(nn.Module):
    def __init__(self, scaling=100., p_gain=1.):
        super(LogCoshPotential, self).__init__()

        self.scaling = scaling * 1.
        self.p_gain = p_gain

    def __call__(self, q):
        q_norm = torch.norm(q, axis=1)
        potential = self.p_gain / self.scaling * torch.log(torch.cosh(q_norm) * 2.)
        return potential

    def grad(self, q):
        n_dims = q.shape[1]
        q_norm = torch.norm(q, dim=1).repeat(n_dims, 1).t()
        s_alpha = torch.tanh(self.scaling * q_norm)
        q_hat = F.normalize(q)
        return self.p_gain * s_alpha * q_hat

    def set_parameters(self, scaling):
        self.scaling = scaling * 1.


class QuadraticPotential(nn.Module):
    def __init__(self, n_dims):
        super(QuadraticPotential, self).__init__()

        self.n_dims = n_dims
        self.hessian = torch.eye(self.n_dims)

    def __call__(self, q, **features):
        if 'potential_minima' in features.keys():
            q = q - features['potential_minima']
        gradient = torch.einsum('ij, bj->bi', self.hessian.to(q.device), q)

        return gradient
