from ngf.controllers.metrics import BarrierMetric, Directional1DToggleMetric, IdentityMetric, FloorLiftMetric, GoalAttractorMetric
from ngf.controllers.potentials import ReluBarrierPotential, LogCoshPotential
from ngf.controllers.controllers import GeometricPolicyController

import numpy as np
import torch


class JointLimitGMP(GeometricPolicyController):
    """
    torch module for joint limit geometric motion policy
    """
    def __init__(self, switch_on=False, epsilon=0., slope_order=2, barrier_gain=4e-1, 
            relu_gain=-5e-2, relu_rate=20., relu_offset=np.pi/6):
        G_limit = BarrierMetric(epsilon=epsilon, slope_order=slope_order)
        G_switch = Directional1DToggleMetric()
        if switch_on:
            G = lambda x, xd: G_limit(x) * G_switch(xd)
        else:
            G = lambda x, xd: G_limit(x)
        # Psi_limit = SlowBarrierWithRadialTogglePotential(proportional_gain=.5)
        psi = ReluBarrierPotential(barrier_gain=barrier_gain, relu_gain=relu_gain, relu_rate=relu_rate, relu_offset=relu_offset)
        phi2 = lambda x, xd: 2.5 * torch.einsum('bi, bi-> b', xd, xd).reshape(-1, 1) * psi.grad(x)
        L = lambda x, xd: 0.5 * xd * G(x, xd) * xd
        super().__init__(Phi2=phi2, L_e=L, name="joint limit") # why dof cspace?

    def forward(self, x, xd):
        return self.geometric_pullback(x, xd)


class DefaultConfigGMP(GeometricPolicyController):
    """
    torch module for default configuration geometric motion policy
    """
    def __init__(self, cspace_dim, metric_scaling=6.):
        G = IdentityMetric(metric_scaling)
        phi2 = lambda q, qd: torch.einsum('bi, bi->b', qd, qd).reshape(-1, 1) * q
        L = lambda q, qd: 0.5*torch.einsum('bi, bij, bj->b', qd, G(q), qd).reshape(-1, 1)
        super().__init__(Phi2=phi2, L_e=L, name="default config")

    def forward(self, x, xd):
        return self.geometric_pullback(x, xd)


class FloorLiftGMP(GeometricPolicyController):
    """
    torch module for floor lift geometric motion policy
    """
    def __init__(self, workspace_dim, proportional_gain=1., length_scale=0.75):
        G = FloorLiftMetric(proportional_gain=proportional_gain, length_scale=length_scale)
        L = lambda x, xd: 0.5*torch.einsum('bi, bij, bj->b', xd, G(x), xd).reshape(-1, 1)

        M = lambda x: torch.tensor([[[20., 0.],[0., 1.]]], device=x.device).repeat(x.size()[0], 1, 1)
        phi2 = lambda x, xd: -5*torch.einsum('bi, j->bj', torch.einsum('bi, bij, bj->b', xd, M(x), xd).reshape(-1, 1), \
                    torch.tensor([0, 1], device=x.device))
        super().__init__(Phi2=phi2, L_e=L, name="floor lifting") # why not learn_geometry?

    def forward(self, x, xd):
        return self.geometric_pullback(x, xd)


class GoalAttractorGMP(GeometricPolicyController):
    """
    torch module for goal attractor geometric motion policy
    """
    def __init__(self, workspace_dim, proportional_gain=10., length_scale=0.25):
        G = GoalAttractorMetric(proportional_gain=proportional_gain, length_scale=length_scale)
        L = lambda x, xd: 0.5*torch.einsum('bi, bij, bj->b', xd, G(x), xd).reshape(-1, 1)
        psi = LogCoshPotential(p_gain=1., scaling=1.0)
        phi2 = lambda x, xd: torch.einsum('bi, bj->bj', torch.einsum('bi, bi->b', xd, xd).reshape(-1, 1), x)
        super().__init__(Phi2=phi2, L_e=L, Psi=psi.grad, target_pos_radius=1., 
            speed_control=True, name="target attractor")

    def forward(self, x, xd):
        return self.geometric_pullback(x, xd)

