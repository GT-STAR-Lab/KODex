import torch
from torch import nn
from ngf.utils.utils import batch_hessian_two
from ngf.utils.log_utils import timing

class LagrangianPolicyController(nn.Module):
    """
    tensorflow module for Lagrangian motion policy based controller
    """
    def __init__(self, L, B=None, f_ext=None, timed=False):
        """
        :param L: lagrangian function handle (takes in position and velocity)
        :param B: Damping function handle (dof x dof, takes in position and velocity)
        :param f_ext: external force handle (dof x 1)
        :param name: name of the module
        """
        super(LagrangianPolicyController, self).__init__()
        self.L = L

        # if B is None:
        #     print('Set damping to ZERO!')
        #     self.B = lambda x, xd: torch.zeros((x.shape[0], x.shape[1], x.shape[1]), dtype=x.dtype, device=x.device)
        # else:
        #     self.B = B
        # self.f_damping = lambda x, xd: torch.einsum('bij, bj->bi', self.B(x, xd), xd)

        # if f_ext is None:
        #     print('Set external force to ZERO!')
        #     self.f_ext = lambda x, xd: torch.zeros_like(x)
        # else:
        #     self.f_ext = f_ext
        
        self.timed = timed

    def calc_force_and_mass(self, x, xd):
        """
        compute the force and mass at state (x, xd) from Lagrangian L
        ------------------------
        :param x: generaized coordinate
        :param xd: generalized velocity
        :return fe: force term from Lagrangian
        :return Me: metric from Lagrangian
        """

        # calculate hessian and gradients of L w.r.t. (x, xd)
        # hessian = ((grad_xx, grad_xxd),(grad_xdx, grad_xdxd)),
        # gradient = (grad_x, grad_xd)
        # where grad_xdxd is the genral mass matrix (metric)
        # and grad_xxd is used to calculate force in Eualer Lagrangian equation,
        # psi=grad_x is used to calculate force in Euler Lagrangian equation Me * xdd + fe = 0
        with timing('calc_force_and_mass', self.timed):
            batch_size, input_size = x.size()
            _, grad_xxd, _, Me, psi, _ = batch_hessian_two(self.L, x, xd, output_numel=1)
            psi = psi.reshape(batch_size, input_size)
            grad_xxd = grad_xxd.reshape(batch_size, input_size, input_size)
            Me = Me.reshape(batch_size, input_size, input_size)
            # calculate force in Eualer Lagrangian equation 
            fe = torch.einsum('bij, bj->bi', grad_xxd, xd) - psi

        return fe, Me

    def __call__(self, x, xd):
        return self.calc_force_and_mass(x, xd)


class GeometricPolicyController(nn.Module):
    """
    tensorflow module for geometric motion policy based controller
    """
    def __init__(self, Phi2, L_e, L_alt=None, Psi=None, 
                 target_pos_radius=None, speed_control=False, 
                 calc_EL=False, debug=False, timed=False, name="geometry"):
        """
        :param Phi2: function that defines the underlying geometry, (takes in position and velocity)
                     homegenous of degree 2 in velocity,
        :param L_e: Lagragian function handle (takes in position and velocity),
                    Finsler energy
        :param L_alt: Lagragian function handle (takes in position and velocity),
                      alternative Finsler energy
        :param Psi: force potential gradient function handle 
        :param target_pos_radius: distance from target pos where damping is applied to optimize Psi
        :param speed_control: whether speed control
        :param calc_EL: whether to calculate E-L equation
        :param debug: whether to print debug infos
        :param timed: whether to time the compilation of the static graph
        :param name: name of the module
        """

        super(GeometricPolicyController, self).__init__()

        self.Phi2 = Phi2
        self.L_e = L_e
        # Euler-Lagrangian (EL)
        self.EL_e = LagrangianPolicyController(L=L_e, timed=timed)

        self.L_alt = L_alt
        if self.L_alt is not None:
            # Euler-Lagrangian (EL)
            self.EL_alt = LagrangianPolicyController(L=L_alt, timed=timed)

        self.Psi = Psi
        self.target_pos_radius = target_pos_radius
        self.speed_control = speed_control
        self.debug=debug
        self.name=name
        self.calc_EL = calc_EL
        print("finished initializating geometric policy!")

    def get_potential_force(self, x, **features):
        """
        gradient of potential field
        ------------------------------
        :param x: generalized coordinate
        :param xd: generalized velocity
        :return grad_psi: potential gradient
        """
        if self.Psi is None:
            return torch.zeros_like(x)
        else:
            return self.Psi(x, **features)
        
    def get_geometry(self, x, xd, **features):
        Phi2 = self.Phi2(x, xd, **features)
        Me = self.L_e.get_metric(x, **features)

        return Phi2, Me

    def get_damping_gate(self, x, scaling_alpha=50.):
        """
        compute the damping switching
        ---------------------------------------
        :param x: generalized coordinate
        :return beta_gate: damping switching gate
        """
        dist = torch.norm(x, axis=1)
        beta_gate = 0.5 * (torch.tanh(-scaling_alpha * (dist - self.target_pos_radius)) + 1)
        return beta_gate

    def geometric_pullback(self, x, xd, root_only=False, **features):
        """
        Given generalized coordinate and velocity, compute the geometry terms
        --------------------------------------------
        :param x: generalized coordinate
        :param xd: generalized velocity
        :return f2: force term from geometry
        :return fe: force term from E-L equation
        :return Me: metric from E-L equation
        :return grad_psi: potential gradients
        :return beta_gate: damping switching gate
        """
        beta_gate = torch.zeros((x.shape[0], 1), dtype=x.dtype, device=x.device)
        grad_Psi = self.get_potential_force(x, **features)

        if self.calc_EL:
            fe, Me = self.EL_e.calc_force_and_mass(x, xd)
            if self.speed_control:
                beta_gate = self.get_damping_gate(x)
        else:
            Phi2 = self.Phi2(x, xd, **features)
            fe = torch.zeros_like(x)
            if root_only:
                Me = torch.eye(x.shape[-1], device=x.device).repeat(x.shape[0], 1, 1)
                f2 = Phi2
            else:
                Me = self.L_e.get_metric(x, **features)
                f2 = torch.einsum('bij,bj->bi', Me, Phi2)

        if self.debug:
            print("--------------------------------------------------")
            print(self.name)
            print("x", x)
            print("xd", xd)
            print("Phi2", Phi2)
            print("fe", fe)
            print("Me", Me)
            print("grad_Psi", grad_Psi)
            print("energy", self.EL_e.L(x, xd))
            print("==================================================")
        return f2, fe, Me, grad_Psi, beta_gate

    def __call__(self, x, xd, root_only=False, **features):
        return self.geometric_pullback(x, xd, root_only=root_only, **features)

    def freeze(self):
        self.Phi2.freeze()
        self.L_e.freeze()