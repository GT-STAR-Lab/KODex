import torch
from torch import nn

config = {
    'shadow_ngf_learning':{
        'geometries':{
            'cspace_geometry':{
                # 'feature_shape': 12,
                # 'feature_keys': ['belief_state'],
                'hidden_units': [128, 64],
                'activation': nn.ReLU(),
                'add_potential': True,
                'use_high_level_policy': False,
            },
        },
        'damping':{
            # 'feature_shape': 12,
            # 'feature_keys': ['belief_state'],
            'hidden_units': [128, 64],
            'activation': nn.ReLU(),
        },
    },
    'shadow_rmp_learning':{
        'rmp':{
            'cspace_rmp':{
                # 'feature_shape': 12,
                # 'feature_keys': ['belief_state'],
                'hidden_units': [128, 64],
                'activation': nn.ReLU(),
                'add_potential': True,
                'use_high_level_policy': False,
            },
        },
        'damping':{
            # 'feature_shape': 12,
            # 'feature_keys': ['belief_state'],
            'hidden_units': [128, 64],
            'activation': nn.ReLU(),
        },
    },
    'motion_policy':{
        # 'feature_shape': 12,
        # 'feature_keys': ['belief_state'],
        'hidden_units': (256, 128),
        'activation': nn.ReLU(),
    },
    'object_net':{
        'net_type': 'tf',
        'state_dim': 6, 
        'hidden_units': (128, 64),
        'activation': nn.ReLU(),
    },
    'belief_net':{
        'embedding_dim': 64,
        'belief_dim': 24,
        'dropout_rate': 0.,
        'feature_shape': 12,
        'feature_keys': ['init_obj'],
    },
    'lfd': {
        'loss': 'huber'
    },
    'optimizer': {
        'lr': 0.001,
        'betas': (0.9, 0.95),
        'weight_decay': 0.1,
    },
    'train': {
        'n_epochs': 10000,
        'batch_size': None,
        'save_best': True,
        'print_freq': 10,
        'checkpoint_freq': 500,
        'stop_threshold': 500,
    },
    'dtype': torch.float32,
    'device': torch.device('cpu'),
}